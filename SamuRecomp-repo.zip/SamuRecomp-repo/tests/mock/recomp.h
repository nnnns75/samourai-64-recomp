// Minimal stand-in for ReBuriki's generated recomp.h, for compiling and testing kernel_sams64.cpp on its own.
// It uses ReBuriki's real memory macros (recomp_mem_section.txt) and hw_mem.h.
#pragma once
#include <stdint.h>
#include <stddef.h>
typedef int64_t gpr;
typedef struct recomp_context {
    gpr r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16,
        r17, r18, r19, r20, r21, r22, r23, r24, r25, r26, r27, r28, r29, r30, r31;
} recomp_context;
typedef void recomp_func_t(uint8_t* rdram, recomp_context* ctx);
#ifdef __cplusplus
extern "C" {
#endif
recomp_func_t* get_function(int32_t vram);
#ifdef __cplusplus
}
#endif
#include "recomp_mem_section.txt"
