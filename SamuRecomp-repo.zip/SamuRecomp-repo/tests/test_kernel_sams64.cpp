// Tests for runtime/kernel_sams64.cpp against a small fake hardware layer.
// Build (ReBuriki unpacked in $RB):
//   g++ -std=c++17 -Wall -I tests/mock -I $RB/recomp/runtime -I runtime \
//       tests/test_kernel_sams64.cpp runtime/kernel_sams64.cpp -o /tmp/test_kernel_sams64 && /tmp/test_kernel_sams64
#include <cstdio>
#include <cstdlib>
#include <cstdarg>
#include <cstring>
#include <vector>
#include "hw.h"
#include "kernel_sams64.h"

// ---- fake hardware ----
uint8_t* g_ram;
uint32_t g_cop0_status = 0;
uint64_t g_ticks, g_next_event; const char* g_func_ring[HW_FUNC_RING]; uint32_t g_func_ring_pos;
void hw_events(uint8_t*, recomp_context*) {}
void (*g_fatal_hook)(const char*) = nullptr;
static uint32_t fake_level = 0;
static std::vector<uint32_t> ack_writes;
struct Tlb { uint32_t index, mask, hi, p0, p1; };
static std::vector<Tlb> tlb_writes;
extern "C" {
uint32_t hw_read32(uint32_t a) { return a == 0xBF701104u ? fake_level : 0xDEAD0000u; }
uint16_t hw_read16(uint32_t) { return 0; }
uint8_t  hw_read8(uint32_t) { return 0; }
void hw_write32(uint32_t a, uint32_t v) { if (a == 0xBF70111Cu) ack_writes.push_back(v); else { printf("unexpected hw write %08X\n", a); exit(1); } }
void hw_write16(uint32_t, uint16_t) {}
void hw_write8(uint32_t, uint8_t) {}
void hw_tlb_write(uint32_t i, uint32_t m, uint32_t h, uint32_t p0, uint32_t p1) { tlb_writes.push_back({i, m, h, p0, p1}); }
[[noreturn]] void hw_fatal(const char* fmt, ...) { va_list ap; va_start(ap, fmt); printf("FATAL: "); vprintf(fmt, ap); printf("\n"); va_end(ap); exit(2); }
}

static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("  FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
static uint32_t ramw(uint32_t a) { return *(uint32_t*)(g_ram + (a & 0x1FFFFFFF)); }
static void setw(uint32_t a, uint32_t v) { *(uint32_t*)(g_ram + (a & 0x1FFFFFFF)) = v; }
static uint8_t ramb(uint32_t a) { return g_ram[(a & 0x1FFFFFFF) ^ 3]; }
static void setb(uint32_t a, uint8_t v) { g_ram[(a & 0x1FFFFFFF) ^ 3] = v; }

// ---- fake game interrupt handler ----
static int handler_calls = 0; static gpr seen_a0, seen_a1, seen_v1; static uint8_t seen_counter; static uint32_t seen_level_word;
static void test_handler(uint8_t*, recomp_context* ctx) {
    handler_calls++; seen_a0 = ctx->r4; seen_a1 = ctx->r5; seen_v1 = ctx->r3;
    seen_counter = ramb(0x80000460 + (fake_level >= 24 ? 13 : fake_level));
    seen_level_word = ramw(0x80000478);
}
extern "C" recomp_func_t* get_function(int32_t v) { if ((uint32_t)v == 0x800C1234u) return test_handler; hw_fatal("unknown function %08X", (uint32_t)v); }

int main() {
    g_ram = (uint8_t*)calloc(1, HW_RAM_SIZE);

    printf("interrupt dispatch, level 3:\n");
    recomp_context ctx = {};
    ctx.r29 = (gpr)(int32_t)0x80003F00u;
    fake_level = 3; setw(0x80000400 + 4 * 3, 0x800C1234); setb(0x80000460 + 3, 7);
    sams_irq_dispatch(g_ram, &ctx);
    CHECK(handler_calls == 1);
    CHECK(seen_counter == 8);                         // counter + 1 while the handler runs
    CHECK(ramb(0x80000460 + 3) == 7);                 // put back afterwards
    CHECK(seen_level_word == 3 && ramw(0x80000478) == 3);
    CHECK(seen_a0 == (gpr)(int32_t)0xBF700000u && seen_a1 == 8 && seen_v1 == 0);
    CHECK(ack_writes.size() == 2 && ack_writes[0] == (1u << 3) && ack_writes[1] == 0);
    CHECK((uint32_t)ctx.r29 == 0x80003F00u - 0x90);   // handler frame

    printf("interrupt dispatch, level 17 (second ack word = 0x80):\n");
    ack_writes.clear(); fake_level = 17; setw(0x80000400 + 4 * 17, 0x800C1234);
    sams_irq_dispatch(g_ram, &ctx);
    CHECK(handler_calls == 2 && seen_v1 == 0x80);
    CHECK(ack_writes.size() == 2 && ack_writes[0] == (1u << 17) && ack_writes[1] == 0x80);

    printf("interrupt dispatch, level 28 (>= 24 uses slot 13, raw level stored):\n");
    ack_writes.clear(); fake_level = 28; setw(0x80000400 + 4 * 13, 0x800C1234);
    sams_irq_dispatch(g_ram, &ctx);
    CHECK(handler_calls == 3 && seen_level_word == 28);
    CHECK(ack_writes.size() == 2 && ack_writes[0] == (1u << 13) && ack_writes[1] == (1u << 6));

    printf("TLB write (func_800C9F90):\n");
    uint32_t blk = 0x80100000;
    uint32_t words[12] = {0x17, 5, 0x01FFE000, 0xC0001234, 0x20000000, 0x30000000, 0, 0, 0, 0, 0xAAAA0A, 0xBBBB0B};
    for (int i = 0; i < 12; i++) setw(blk + 4 * i, words[i]);
    ctx.r4 = (gpr)(int32_t)blk; ctx.r8 = 111; ctx.r9 = 222; gpr sp0 = ctx.r29;
    func_800C9F90(g_ram, &ctx);
    CHECK(tlb_writes.size() == 1);
    CHECK(tlb_writes[0].index == 5 && tlb_writes[0].mask == 0x01FFE000 && tlb_writes[0].hi == 0xC0000000u);
    CHECK(tlb_writes[0].p0 == 0x20000000u && tlb_writes[0].p1 == 0x30000000u);
    CHECK((uint32_t)ctx.r10 == 0xAAAA0A && (uint32_t)ctx.r11 == 0xBBBB0B);   // t2, t3 as the original leaves them
    CHECK(ctx.r8 == 111 && ctx.r9 == 222 && ctx.r29 == sp0);                  // t0, t1, sp unchanged

    printf("cache functions:\n");
    ctx.r4 = ctx.r5 = ctx.r6 = 0; func_800CA03C(g_ram, &ctx);
    CHECK((uint32_t)ctx.r4 == 0x80002000u && (uint32_t)ctx.r5 == 0x80002000u && ctx.r6 == 0x10);
    func_800CA018(g_ram, &ctx); func_800CA124(g_ram, &ctx);
    gpr r8 = ctx.r8, r29 = ctx.r29; func_800CA09C(g_ram, &ctx); func_800CA0E0(g_ram, &ctx);
    CHECK(ctx.r8 == r8 && ctx.r29 == r29);

    printf(fails ? "\n%d check(s) FAILED\n" : "\nall checks passed\n", fails);
    return fails ? 1 : 0;
}
