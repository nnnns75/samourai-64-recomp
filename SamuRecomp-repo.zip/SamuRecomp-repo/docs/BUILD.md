# Building SamuRecomp (Samurai Shodown 64)

You build the game yourself, from ROM sets you own. Nothing below downloads or contains game data.

Tested on: Ubuntu 22.04 (a distrobox container on a Steam Deck works), Python 3.11, then run with Wine.
The compiled program is a Windows `.exe` (cross-compiled with llvm-mingw), so it also runs on Windows.

## What you need

- `sams64.zip` and `hng64.zip` (MAME names; the unpack step finds files by checksum). `hng64.zip` must include
  `tmp87ph40an.bin` (the I/O board firmware).
- Ubuntu 22.04 with: `git cmake build-essential python3.11 curl xz-utils` (and, to test, `wine xvfb`).
- [N64Recomp](https://github.com/N64Recomp/N64Recomp) at commit `598ce20` (the version these scripts were tested
  with), built once:

```bash
git clone https://github.com/N64Recomp/N64Recomp ~/N64Recomp
cd ~/N64Recomp && git checkout 598ce20 && git submodule update --init --recursive
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release && cmake --build build -j
ls build/N64Recomp          # must exist
```

## Steps

Run these from the repository folder (called `$REPO` here). Each command stops with a message if something is
wrong, and nothing is written half-way.

```bash
cd $REPO

# 1. take the files the port needs out of your ROM zips -> roms/sams64 and roms/hng64
python3 tools/sams64/unpack_roms_sams64.py --fork . --game ~/sams64.zip --bios ~/hng64.zip

# 2. translate the game's program to C (recomp/generated/, work/): derived from your ROM, never publish
python3.11 tools/sams64/translate_sams64.py --fork . --game ~/sams64.zip --n64recomp ~/N64Recomp

# 3. compile -> build/samurecomp.exe  (downloads llvm-mingw once into ~/llvm-mingw, about 200 MB)
python3.11 tools/sams64/build_sams64_linux.py --fork . --n64recomp ~/N64Recomp
```

The first build takes 10 to 30 minutes; a rebuild after changing one `.cpp` file is quick.

## Run

```bash
export WINEPREFIX=$HOME/.wine-ss64 WINEDEBUG=-all
wine build/samurecomp.exe --roms roms --bios brom1.bin --scale 2          # window
xvfb-run -a wine build/samurecomp.exe --headless --no-sound --frames 3000 --roms roms \
    --dump-dir frames --dump-frames 1500,2400 --input-script "2350=coin1;2380=;2500=p1start;2510="   # no screen
```

Options are listed at the top of `recomp/runtime/main.cpp`. Settings, controls and the arcade save memory are kept
next to the program (`settings.ini`, `controls.ini`, `nvram.bin`).

## Checks that are worth running

- `python3 tools/sams64/audit_sams64.py --fork .` after a translation: lists jump tables the translator did not
  recognise (an unrecognised one stops the game with `[FATAL] indirect call to ...`; fix it in
  `fix_switches_sams64.py`) and data pointers that are not function starts (`EXTRA_STARTS` in `extract_sams64.py`).
- Boot test: run headless for 3000 frames with the input script above and look at the dumped frames.

## When something does not work

The diagnostic scripts in `tools/sams64/` are how the port was debugged; see [BOOT_PLAN.md](BOOT_PLAN.md).
Apply them (they patch `recomp/runtime/hw.cpp`, then rebuild) with, in this order:
`diagwatch_sams64.py`, `diagcov_sams64.py`, `diagprof_sams64.py`; then `autodiag_all_sams64.py` runs the whole method
(profile of the busiest functions, coverage, "gates" that run but never take a branch, watched variables).

## What the scripts did to your tree

`apply_sams64_patch.py`, `rename_sams64.py`, `options_sams64.py` and `fix_vblank_sams64.py` have **already been
applied** in this repository's `recomp/runtime`; they are kept to show exactly what differs from ReBuriki and to
re-apply on a fresh ReBuriki checkout. `translate_sams64.py` installs `tools/sections.py` for this game (keeping the
original as `tools/sections_buriki.py`) and writes `tools/data/functions_*_sams64.txt` (ignored by git).

## Windows

`translate_sams64.py` runs on Windows too, but the compile step here is Linux cross-compilation. A native Windows
build and a `Setup.exe` like ReBuriki's still have to be adapted (ReBuriki's `tools/install` and
`tools/build_recomp.ps1` are the starting point).
