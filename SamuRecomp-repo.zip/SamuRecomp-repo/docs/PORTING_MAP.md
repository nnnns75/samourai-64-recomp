# Carte du portage : ce qui est propre a Buriki One dans ReBuriki

Etablie en lisant `ReBuriki-main.zip` (MIT + parties MAME en LGPL/BSD). Les references viennent du code et de
`NOTES.md` du depot. **Rien ici n'a ete teste sur une ROM de Samurai Shodown 64** : je n'en ai pas.

## 1. Ce qui est commun a toute la carte HNG64 (a reutiliser tel quel)

| Element | Ou |
|---|---|
| Carte memoire, interruptions, DMA, RTC | `recomp/runtime/hw.cpp`, `hw.h`, `hw_mem.h` |
| Video 2D/3D (port de MAME `hng64*`), rendu D3D11 | `video.cpp`, `video3d.cpp`, `hd3d.cpp`, `frontend/fe_d3d11.cpp` |
| Carte son (V53, L7A1045) | `sound.cpp`, `l7a1045.cpp`, `audiocpu/*` |
| Carte I/O (microcontroleur TLCS-870) | `io_board.cpp`, `iomcu/*` |
| Fenetre, menu, manettes, sauvegardes d'etat, netplay | `frontend/*`, `savestate.*`, `netplay.*`, `pagestate.cpp` |
| BIOS (fonctions de service, liste `functions_bios.txt`) | meme `hng64.zip` pour tous les jeux |

## 2. Ce qu'il faut refaire pour Samurai Shodown 64

| # | Point propre a Buriki One | Fichier | A faire pour SS64 |
|---|---|---|---|
| 1 | Liste ROM + CRC (`GAME_ROMS`), noms `007pr01b.81`, dossier `buriki` | `tools/install/build_from_rom.py` | Generer depuis `profile.json` (sortie de `analyze_hng64_game.py`) |
| 2 | Interleave pr01+pr02, bloc `0x100000-0x1FFFFF` | `build_from_rom.py` `make_images` | Offset/taille tires de l'en-tete de SS64 (l'analyseur les calcule et signale les ecarts) |
| 3 | Sections et listes de fonctions (Ghidra) | `tools/sections.py`, `tools/data/functions_game.txt`, `extra_functions.txt` | Nouvelle liste: partir de `functions_seed.txt`, affiner avec `tools/ghidra_scripts/SeedAndExport.java` |
| 4 | 7 fonctions `ignored` (adresses `func_800C2420`, `func_800C5C90`, `func_800C5D30`, services BIOS) | `recomp/buriki.toml`, `kernel_funcs.txt` | `kernel_candidates.txt` donne les candidates; les reecrire a la main |
| 5 | Implementations noyau: crash, TLB, **RNG** (table `0x800DCE00`, `gp+0x2c44`) | `runtime/kernel.cpp` | A relire dans Ghidra pour SS64 (le RNG est specifique au jeu) |
| 6 | Dispatcheur d'IRQ `func_800C2B20`, table `0x80000400`, `gp=0x800F11D0` | `runtime/hw.cpp` (~l.712, ~l.793-800), `NOTES.md` | Retrouver l'equivalent dans le code de SS64 |
| 7 | Etat de combat `0x800F3A51`, nvram <-> RAM `0x801446E0/0x801446F0` (options operateur) | `runtime/hw.cpp` (~l.368-393) | Retrouver ces adresses par observation avec les diagnostics du runtime (`BURIKI_WATCH`, `BURIKI_RAMDUMP`, `BURIKI_POKE`, decrits dans `hw.cpp`) et MAME |
| 8 | Boucle principale `func_800080B0`, label `L_800080F0`, `WAIT_SP=0x803FFFC0` | `savestate.h`, `netplay.cpp` | Seulement si tu veux rollback/netplay; sinon a ignorer au debut |
| 9 | Point d'entree `func_80008000` | `runtime/main.cpp` l.291, `extra_functions.txt` | En-tete +0x5C de SS64 |
| 10 | Controles: Buriki = 2 boutons de deplacement + stick pour attaquer | `frontend/fe_input.cpp`, `menu.cpp`, `README` | SS64 est un jeu d'armes classique (stick + boutons): refaire les schemas |
| 11 | Pages Rules/Game du menu (options operateur, Silber, widescreen/HUD) | `frontend/menu.cpp`, `settings.cpp`, `fe_menu_host.cpp` | Retirer ce qui est Buriki; recreer d'apres le menu Test de SS64 |
| 12 | Noms de produit | `tools/install/product.py` | Voir `tools/product_sams64.py` |
| 13 | Divers noms `BURIKI_*` (variables d'env, `buriki.syms.toml`, `buriki_code_*.bin`) | un peu partout (voir `grep -ril buriki`) | Renommer |

## 3. Risques a verifier avant de s'engager

- **Carte I/O**: ReBuriki embarque le "hack" MAME du dualport `0x600 = 1` (carte combat). A confirmer dans
  `hng64.cpp` de MAME pour SS64, et pour les 3 jeux hors combat (Beast Busters, Road's Edge, Xtreme Rally)
  qui, a ma connaissance, n'utilisent pas la meme carte I/O.
- **Fonctions MAME propres a SS64**: SS64 peut utiliser des fonctions video/son que Buriki One n'exerce pas;
  elles seraient alors incompletes dans le runtime. `NOTES.md` liste deja des lacunes (ex. effet "delay" du son).
- **Compatibilite BIOS**: les listes de fonctions du BIOS ont ete etablies pour `brom1.bin`. Verifie les CRC des
  variantes (`bios_us`, `bios_export`) comme le fait `SYSTEM_ROMS`.
- **Licences**: le runtime contient des ports de MAME (LGPL-2.1+ / BSD-3). Un fork doit garder ces licences et
  les en-tetes de fichiers (voir `LICENSE.md` de ReBuriki). Ne publie jamais de ROM ni de code produit a partir d'elles.
