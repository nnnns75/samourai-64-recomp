#!/usr/bin/env python3
"""Diagnostic global (tout en un) pour Samurai Shodown 64.

Enchaine automatiquement:
  1. applique les patchs de diagnostic du runtime (idempotents) et recompile
  2. lance le jeu avec le script d'entrees; profile les fonctions les plus appelees apres l'image --from
     (= la boucle ou le jeu reste bloque) et releve la couverture
  3. pour chaque fonction chaude: variables (gp+offset) qu'elle LIT, fonctions qui les ECRIVENT,
     et si ces ecrivains sont executes
  4. 2e lancement: surveille ces variables et dit lesquelles ne changent jamais
  5. ecrit un rapport unique: ~/diag_report.txt (colle-le en entier)

Usage:  cd ~/Downloads/files/tools ; python3 autodiag_all_sams64.py --fork ~/SamuRecomp
Options: --from 3700 --frames 4200 --input "3000=coin1;3004=;3300=p1start;3304=" --top 8 --skip-build
"""
import argparse, glob, os, re, shutil, subprocess, sys
from collections import defaultdict

GP = 0x8006CA90
HERE = os.path.dirname(os.path.abspath(__file__))

ap = argparse.ArgumentParser()
ap.add_argument("--fork", required=True)
ap.add_argument("--from", dest="from_", type=int, default=3700)
ap.add_argument("--frames", type=int, default=4200)
ap.add_argument("--input", default="3000=coin1;3004=;3300=p1start;3304=")
ap.add_argument("--top", type=int, default=8)
ap.add_argument("--skip-build", action="store_true")
a = ap.parse_args()
fork = os.path.abspath(os.path.expanduser(a.fork))
gen = os.path.join(fork, "recomp", "generated")
report = []


def out(s=""):
    print(s, flush=True)
    report.append(s)


def find(name):
    for d in (HERE, os.path.join(HERE, ".."), os.path.join(HERE, "..", "tools"), os.getcwd()):
        p = os.path.join(d, name)
        if os.path.exists(p):
            return os.path.abspath(p)
    return None


# ---- 1. patchs + build ----------------------------------------------------------------------
out("== 1. patchs de diagnostic ==")
for t in ("diagwatch_sams64.py", "diagcov_sams64.py", "diagprof_sams64.py"):
    p = find(t)
    if not p:
        sys.exit("script manquant dans le dossier: " + t)
    r = subprocess.run([sys.executable, p, "--fork", fork], capture_output=True, text=True)
    out("  %s: %s" % (t, (r.stdout + r.stderr).strip().splitlines()[-1] if (r.stdout + r.stderr).strip() else "?"))
    if r.returncode != 0:
        sys.exit("echec du patch " + t)

if not a.skip_build:
    b = find("build_sams64_linux.py")
    if not b:
        sys.exit("build_sams64_linux.py introuvable (le mettre dans files/ ou files/tools/)")
    py = shutil.which("python3.11") or sys.executable
    out("== compilation (peut prendre quelques minutes) ==")
    r = subprocess.run([py, b, "--fork", fork, "--n64recomp", os.path.expanduser("~/N64Recomp")])
    if r.returncode != 0:
        sys.exit("echec de la compilation")

env = dict(os.environ)
env.setdefault("WINEPREFIX", os.path.expanduser("~/.wine-ss64"))
env["WINEDEBUG"] = "-all"


def run_game(extra_env, tag):
    e = dict(env); e.update(extra_env)
    cmd = ["xvfb-run", "-a", "wine", "build/samurecomp.exe", "--headless", "--no-sound",
           "--frames", str(a.frames), "--roms", "roms", "--input-script", a.input]
    out("== lancement du jeu (%s, %d images) ==" % (tag, a.frames))
    r = subprocess.run(cmd, cwd=fork, env=e, capture_output=True, text=True, errors="replace")
    return (r.stdout + "\n" + r.stderr).replace("\r", "")


# ---- 2. profil + couverture -----------------------------------------------------------------
cov_file = os.path.join(fork, "cov_auto.txt")
if os.path.exists(cov_file):
    os.remove(cov_file)
log1 = run_game({"BURIKI_PROF_FROM": str(a.from_), "BURIKI_COVERAGE": "cov_auto.txt"}, "profil")
prof = [(int(m.group(1)), m.group(2)) for m in re.finditer(r"\[prof\]\s+(\d+)\s+(func_[0-9A-F]+)", log1)]
if not prof or not os.path.exists(cov_file):
    out("ERREUR: pas de profil/couverture (diagwatch/diagcov/diagprof bien appliques et compiles ?)")
    open(os.path.expanduser("~/diag_report.txt"), "w").write("\n".join(report))
    sys.exit(1)
executed = set(re.findall(r"func_[0-9A-F]+", open(cov_file, errors="replace").read()))
out("fonctions executees au total: %d" % len(executed))
out("")
out("== 2. fonctions les plus appelees apres l'image %d ==" % a.from_)
for n, f in prof[:15]:
    out("  %10d  %s" % (n, f))

# ---- 3. analyse statique ---------------------------------------------------------------------
bodies, writers, calls = {}, defaultdict(set), defaultdict(set)
rf = re.compile(r"^RECOMP_FUNC void (func_[0-9A-F]+)\(")
rc = re.compile(r"^\s*(func_[0-9A-F]{8})\(rdram, ctx\);")
ld = re.compile(r"MEM_(?:BU|B|HU|H|W)\(ctx->r28, (-?)0X([0-9A-F]+)\)")
st = re.compile(r"MEM_(?:B|H|W)\((-?)0X([0-9A-F]+), ctx->r28\)\s*=")
loads = defaultdict(set)
cur = None
for f in sorted(glob.glob(os.path.join(gen, "funcs_*.c"))):
    for l in open(f, errors="replace"):
        m = rf.match(l)
        if m:
            cur = m.group(1); continue
        if cur is None:
            continue
        m = rc.match(l)
        if m:
            calls[cur].add(m.group(1))
        for m in ld.finditer(l):
            off = int(m.group(2), 16) * (-1 if m.group(1) else 1)
            loads[cur].add(off)
        m = st.search(l)
        if m:
            off = int(m.group(2), 16) * (-1 if m.group(1) else 1)
            writers[off].add(cur)

out("")
out("== 3. variables (gp+offset) lues par les fonctions chaudes ==")
watch_addrs = []
for n, fn in prof[:a.top]:
    offs = sorted(loads.get(fn, []))
    out("-- %s (%d appels): lit %d variables gp" % (fn, n, len(offs)))
    for off in offs:
        addr = (GP + off) & 0xFFFFFFFF
        w = sorted(writers.get(off, []))
        ws = ", ".join("%s%s" % (x, "" if x in executed else "(JAMAIS executee)") for x in w[:6]) or "aucun ecrivain direct"
        out("     gp%+#x = 0x%08X   ecrit par: %s" % (off, addr, ws))
        if addr not in watch_addrs:
            watch_addrs.append(addr)

# ---- 4. surveillance des variables ----------------------------------------------------------
watch_addrs = watch_addrs[:15]
spec = ",".join("0x%08X" % (ad + i) for ad in watch_addrs for i in range(4))
log2 = run_game({"BURIKI_WATCH": spec}, "surveillance")
last = {}
for m in re.finditer(r"\[watch\] frame (\d+): ([0-9A-F]{8}) = ([0-9A-F]{2})", log2):
    fr, ad, v = int(m.group(1)), int(m.group(2), 16), m.group(3)
    last[ad] = (fr, v)
out("")
out("== 4. variables surveillees: dernier changement ==")
for ad in watch_addrs:
    vals = [last.get(ad + i) for i in range(4)]
    chg = [x[0] for x in vals if x]
    val = "".join((last[ad + i][1] if (ad + i) in last else "00") for i in range(4))
    if not chg:
        out("  0x%08X : JAMAIS modifiee (reste 0)" % ad)
    else:
        out("  0x%08X : derniere valeur %s, dernier changement image %d%s" % (
            ad, val, max(chg), "   <-- fige bien avant la fin" if max(chg) < a.from_ - 300 else ""))

out("")
out("Rapport enregistre dans ~/diag_report.txt -- colle-le en entier.")
open(os.path.expanduser("~/diag_report.txt"), "w").write("\n".join(report))
