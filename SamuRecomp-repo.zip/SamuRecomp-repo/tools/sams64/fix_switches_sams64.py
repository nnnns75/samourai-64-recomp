#!/usr/bin/env python3
"""
Remplace les 'jr reg' que N64Recomp n'a pas reconnus comme tables de sauts par un vrai switch (goto vers des etiquettes
dans la meme fonction). Les cibles sont lues dans l'image memoire de la ROM (work/sams64_image_8006AA00.bin).

    python3 fix_switches_sams64.py --fork ~/SamuRecomp

Ajouter un cas = une ligne dans SWITCHES (l'audit tools/audit_sams64.py liste ceux qui restent). Sans effet si deja applique.
"""
import argparse
import os
import re
import struct
import sys

IMG_BASE = 0x8006AA00

# (fonction, adresse du 'jr', adresse de la table, nombre d'entrees)
#  func_801129F4: s3 = 0x802A43F0 avance de 4 a chaque tour (delai du 'bne' final); 'sltiu s0,13' borne l'indice a 13 cas.
SWITCHES = [
    (0x801129F4, 0x80112A78, 0x802A43F0, 13),
]

BRANCH = re.compile(r"//\s+0x[0-9A-F]{8}:\s+(j|jal|jr|jalr|b\w*)\s")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fork", required=True)
    a = ap.parse_args()
    gen = os.path.join(os.path.abspath(os.path.expanduser(a.fork)), "recomp", "generated")
    img = open(os.path.join(os.path.dirname(gen), "..", "work", "sams64_image_8006AA00.bin"), "rb").read()
    files = {f: open(os.path.join(gen, f), encoding="utf-8").read().split("\n")
             for f in sorted(os.listdir(gen)) if f.startswith("funcs_") and f.endswith(".c")}
    for fn, jr, table, count in SWITCHES:
        targets = [struct.unpack(">I", img[table - IMG_BASE + 4 * k:table - IMG_BASE + 4 * k + 4])[0] for k in range(count)]
        head = f"RECOMP_FUNC void func_{fn:08X}("
        fname = next((f for f, L in files.items() if any(l.startswith(head) for l in L)), None)
        if not fname:
            sys.exit(f"erreur: func_{fn:08X} introuvable dans {gen}")
        L = files[fname]
        s = next(i for i, l in enumerate(L) if l.startswith(head))
        e = next((i for i in range(s + 1, len(L)) if L[i].startswith("RECOMP_FUNC void ")), len(L))
        body = L[s:e]
        if any("SAMS64_SWITCH" in l for l in body):
            print(f"func_{fn:08X}: deja corrige")
            continue
        fend = fn + 4 * sum(1 for l in body if re.match(r"\s*// 0x[0-9A-F]{8}:", l))   # borne large, verif. ci-dessous
        bad = [t for t in targets if not (fn <= t < fend + 0x10000) or t % 4]
        if bad:
            sys.exit(f"erreur: cibles hors de la fonction: {[hex(t) for t in bad]} (table 0x{table:08X} mal placee?)")
        k = next((i for i, l in enumerate(body) if re.match(rf"\s*// 0x{jr:08X}:\s+jr\s", l)), None)
        if k is None:
            sys.exit(f"erreur: 'jr' a 0x{jr:08X} introuvable dans func_{fn:08X}")
        j = k
        while j < len(body) and "LOOKUP_FUNC(" not in body[j]:
            j += 1
        if j >= len(body) or not any("return;" in x for x in body[j:j + 4]) or "nop" not in " ".join(body[k:k + 3]):
            sys.exit(f"erreur: forme inattendue autour de 0x{jr:08X} (delai non nop ou pas un appel terminal)")
        reg = re.search(r"LOOKUP_FUNC\((ctx->r\d+)\)", body[j]).group(1)
        uniq = sorted(set(targets))
        # etiquettes: une par cible, devant l'instruction (copie du delai de saut exclue)
        for t in uniq:
            pat = re.compile(rf"\s*// 0x{t:08X}:")
            idx = [i for i, l in enumerate(body) if pat.match(l)]
            if not idx:
                sys.exit(f"erreur: cible 0x{t:08X} sans instruction dans func_{fn:08X}")
            prev = [i for i, l in enumerate(body) if re.match(rf"\s*// 0x{t - 4:08X}:", l)]
            is_delay = any(BRANCH.search(body[i]) for i in prev)
            body[idx[-1] if is_delay else idx[0]] = f"    L_sw_{t:08X}:;  // SAMS64_SWITCH\n" + body[idx[-1] if is_delay else idx[0]]
        # remplacement de l'appel terminal
        cases = "\n".join(f"        case 0x{t:08X}: goto L_sw_{t:08X};" for t in uniq)
        body[j] = (f"    switch ((uint32_t){reg}) {{   // SAMS64_SWITCH: jr de la table 0x{table:08X} ({count} cas)\n{cases}\n"
                   f"        default: break;\n    }}\n    LOOKUP_FUNC({reg})(rdram, ctx);")
        files[fname][s:e] = body
        print(f"func_{fn:08X}: switch a {len(uniq)} cibles ({', '.join('%08X' % t for t in uniq[:4])}...)")
    for f, L in files.items():
        open(os.path.join(gen, f), "w", encoding="utf-8", newline="\n").write("\n".join(L))


if __name__ == "__main__":
    main()
