#!/usr/bin/env python3
"""
Extraction des segments de Samurai Shodown 64 (Samurai Spirits 64, HNG64) a partir de TA ROM.

    python3 extract_sams64.py --game sams64.zip --out work_sams64 [--prog-lo F --prog-hi F]

La carte memoire ci-dessous est DECODEE du crt0 de la ROM (listing de l'amorce, ROM 0x200-0x440),
pas devinee. Le script verifie d'abord que ta ROM contient bien les memes instructions aux memes
offsets; sinon il s'arrete (autre revision: il faut redecoder le crt0 avec analyze_hng64_game.py --list).

Sorties dans --out :
  sams64_image_8006AA00.bin  memoire du jeu 0x8006AA00-0x802C8700 (donnees + code + donnees), lue par N64Recomp
  sams64_text_800C0000.bin   code du jeu seul         ROM 0x5360..0xA3E60 -> 0x800C0000
  sams64_stub_80001000.bin   amorce (BIOS)       ROM 0x200..0x1200   -> 0x80001000
  segments.json              la table des copies du crt0
  functions_text.txt         graines de fonctions du code ("debut fin"), a affiner dans Ghidra
  sams64_low_80000800.bin    zone du gestionnaire (ROM 0x500 -> 0x80000800), 9 petites fonctions recompilables
  functions_low.txt          leurs bornes
  functions_stub.txt         les 3 fonctions du crt0 (0x80001000-0x800012D8), fixees d'apres le listing
  kernel_candidates.txt      fonctions utilisant des instructions COP0 non traduisibles (code du jeu seulement)
"""
import argparse
import json
import os
import sys
import zipfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from analyze_hng64_game import (JR_RA, KSEG0, be_words, classify_cop0, find_program_roms,  # noqa: E402
                                interleave_be)

# Controle: (offset ROM, mot attendu) pris dans le listing du crt0 de Samurai Spirits 64.
SANITY = [(0x200, 0x3C1D8000), (0x208, 0x3C1C8007), (0x20C, 0x279CCA90), (0x2BC, 0x3C048007), (0x2C0, 0x2484AA00),
          (0x2C8, 0x24634960), (0x2EC, 0x3C05A400), (0x2F0, 0x24A55360), (0x2FC, 0x3C03000A), (0x300, 0x2463EB00),
          (0x32C, 0x3C048018), (0x334, 0x3C030015), (0x338, 0x24638700), (0x420, 0x0C033BD4)]

# Copies faites par le crt0 (ROM -> RAM). rom/size/vram decodes des lui/addiu du listing.
SEGMENTS = [
    dict(name='stub',  rom=0x000200, size=0x001000, vram=0x80001000, by='BIOS (en-tete +0x50/+0x54/+0x58)',
         note="amorce: crt0 (0x80001000), test RAM (0x80001240), vecteur d'exception (0x800012E4), gestionnaire (source 0x80001300)"),
    dict(name='handler', rom=0x000500, size=0x000500, vram=0x80000800, by='crt0',
         note="gestionnaire d'exceptions/interruptions: contient eret et mtc0/mfc0 -> a reecrire a la main dans le runtime"),
    dict(name='data',  rom=0x000A00, size=0x004960, vram=0x8006AA00, by='crt0', note='donnees (.data)'),
    dict(name='text',  rom=0x005360, size=0x09EB00, vram=0x800C0000, by='crt0', note='code du jeu'),
    dict(name='data2', rom=0x0A3E60, size=0x148700, vram=0x80180000, by='crt0', note='donnees (apres le code)'),
]
BSS = dict(vram=0x80004000, size=0x669F4)       # zone mise a zero par le crt0 (0x80004000..0x8006A9F4)
SP, GP, MAIN = 0x80004000, 0x8006CA90, 0x800CEF50   # pile initiale, gp, main (jal final du crt0)
STUB_CODE_END = 0x800012D8                       # fin du dernier 'jr ra' du crt0/test RAM
# Petites fonctions de la zone du gestionnaire (copie 1: ROM 0x500 -> 0x80000800), toutes finissant par 'jr ra' (verifie
# sur le listing). Elles n'utilisent que Status, cfc1/ctc1, sdc1/ldc1, mfhi/mflo: N64Recomp les traduit, pas de reecriture.
# Le gestionnaire lui-meme (0x80000800-0x80000A98, avec eret) est exclu: voir kernel_sams64.cpp.
LOW_FUNCS = [(0x80000A98, 0x80000B04),   # sauvegarde des registres flottants (sdc1 x20 + cfc1)
             (0x80000B04, 0x80000B6C),   # restauration des registres flottants
             (0x80000B6C, 0x80000BD4),   # sauvegarde de a2..fp
             (0x80000BD4, 0x80000C3C),   # restauration de a2..fp
             (0x80000C3C, 0x80000C6C),   # Status = (Status & 0xFFFFFFE1) | 0x10401   (IE, IM2, bit 16; efface EXL/ERL/KSU)
             (0x80000C6C, 0x80000C88),   # Status |= 1   (autorise les interruptions)
             (0x80000C88, 0x80000CA8),   # Status &= ~1  (les interdit)
             (0x80000CA8, 0x80000CC8),   # Status = 0x30010401   (CU0|CU1, IM2, IE; FR=0 !)
             (0x80000CC8, 0x80000CE8)]   # Status = 0x30010400   (idem sans IE; FR=0 !)
# Fonctions du crt0, fixees a la main d'apres le listing (l'heuristique couperait le test RAM en 3 alors que ses
# 'bne' sautent vers 0x800012C4, a l'interieur de la meme fonction):
STUB_FUNCS = [(0x80001000, 0x80001238),    # crt0: sp/gp, test RAM, copies ROM->RAM, remise a zero, jal main
              (0x80001238, 0x80001240),    # 'jr ra' vide
              (0x80001240, 0x800012D8)]    # test de RAM par motifs 0x55555555/0xAAAAAAAA, renvoie 0 (ok) ou 1


def fail(m):
    sys.exit("erreur: " + m)


# Debuts de fonctions ajoutes a la main (cibles de 'jalr' que les graines n'ont pas vues). Le runtime les signale:
# "[FATAL] indirect call to 800Cxxxx, which isn't a known function start".
EXTRA_STARTS = []


def seeds(words, base, lo, hi, extra=()):
    """Graines de fonctions: apres 'jr ra'+delay slot, et cibles de 'jal' dans [lo,hi). Fin = debut suivant."""
    n = len(words)
    st = set(extra)
    for i in range(n):
        if words[i] == JR_RA:
            j = i + 2
            while j < n and words[j] == 0:
                j += 1
            if j < n:
                st.add(base + j * 4)
    for w in words:
        if w >> 26 == 3:
            t = ((w & 0x3FFFFFF) << 2) | (base & 0xF0000000)
            if lo <= t < hi:
                st.add(t)
    st = sorted(x for x in st if lo <= x < hi)
    return [(s, st[k + 1] if k + 1 < len(st) else hi) for k, s in enumerate(st)]


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--game', required=True)
    ap.add_argument('--out', required=True)
    ap.add_argument('--prog-lo')
    ap.add_argument('--prog-hi')
    a = ap.parse_args()

    z = zipfile.ZipFile(a.game)
    lo_n, hi_n = find_program_roms(z, a.prog_lo, a.prog_hi)
    be = interleave_be(z.read(lo_n), z.read(hi_n))
    print(f"ROMs programme: {lo_n} + {hi_n} ({len(be) >> 20} Mo)")

    bad = []
    for off, exp in SANITY:
        got = int.from_bytes(be[off:off + 4], 'big')
        if got != exp:
            bad.append((off, exp, got))
    if bad:
        for off, exp, got in bad[:6]:
            print(f"  ROM 0x{off:X}: attendu {exp:08X}, trouve {got:08X}")
        fail(f"{len(bad)} controle(s) du crt0 en echec: ce n'est pas la ROM dont la carte memoire a ete decodee. "
             "Relance analyze_hng64_game.py --list 0x200 300 et redecode.")
    print(f"Controle du crt0: {len(SANITY)}/{len(SANITY)} instructions identiques.")

    # coherence interne: les copies se suivent sans trou dans la ROM
    assert SEGMENTS[2]['rom'] + SEGMENTS[2]['size'] == SEGMENTS[3]['rom']
    assert SEGMENTS[3]['rom'] + SEGMENTS[3]['size'] == SEGMENTS[4]['rom']
    if SEGMENTS[4]['rom'] + SEGMENTS[4]['size'] > len(be):
        fail("la copie 4 depasse l'image ROM")

    os.makedirs(a.out, exist_ok=True)
    seg = {s['name']: s for s in SEGMENTS}
    text = be[seg['text']['rom']:seg['text']['rom'] + seg['text']['size']]
    stub = be[seg['stub']['rom']:seg['stub']['rom'] + seg['stub']['size']]
    # Image continue de la memoire du jeu (donnees 0x8006AA00, code 0x800C0000, donnees 0x80180000), trous remplis de zeros.
    # N64Recomp cherche une table de sauts dans la ROM a (adresse de la table - adresse de la fonction) de distance de la
    # fonction elle-meme: les tables du jeu (ex. 0x80287450) sont dans les donnees, pas dans le code.
    IMG_BASE = seg['data']['vram']
    img_end = seg['data2']['vram'] + seg['data2']['size']
    image = bytearray(img_end - IMG_BASE)
    for name in ('data', 'text', 'data2'):
        sg = seg[name]
        image[sg['vram'] - IMG_BASE:sg['vram'] - IMG_BASE + sg['size']] = be[sg['rom']:sg['rom'] + sg['size']]
    ipath = os.path.join(a.out, 'sams64_image_%08X.bin' % IMG_BASE)
    open(ipath, 'wb').write(image)
    tpath = os.path.join(a.out, 'sams64_text_800C0000.bin')
    spath = os.path.join(a.out, 'sams64_stub_80001000.bin')
    open(tpath, 'wb').write(text)
    open(spath, 'wb').write(stub)
    hand = be[seg['handler']['rom']:seg['handler']['rom'] + seg['handler']['size']]
    hpath = os.path.join(a.out, 'sams64_low_80000800.bin')
    open(hpath, 'wb').write(hand)
    with open(os.path.join(a.out, 'functions_low.txt'), 'w') as f:
        for s_, e_ in LOW_FUNCS:
            f.write('%08x %08x\n' % (s_, e_))
    json.dump(dict(segments=SEGMENTS, bss=BSS, sp=SP, gp=GP, main=MAIN, entry=0x80001000),
              open(os.path.join(a.out, 'segments.json'), 'w'), indent=2)

    tv, tend = seg['text']['vram'], seg['text']['vram'] + len(text)
    tw = be_words(text)
    # tv = debut du code: la 1re fonction (0x800C0000, 'jr ra; nop', gestionnaire par defaut du jeu) n'est ni une cible
    # de jal ni derriere un 'jr ra'. EXTRA_STARTS: debuts de fonctions appeles par pointeur, decouverts au lancement.
    ts = seeds(tw, tv, tv, tend, extra=[MAIN, tv] + EXTRA_STARTS)
    with open(os.path.join(a.out, 'functions_text.txt'), 'w') as f:
        for s, e in ts:
            f.write('%08x %08x\n' % (s, e))
    ss = STUB_FUNCS
    with open(os.path.join(a.out, 'functions_stub.txt'), 'w') as f:
        for s_, e_ in ss:
            f.write('%08x %08x\n' % (s_, e_))

    starts = [s for s, _ in ts]
    kern = {}
    for i, w in enumerate(tw):
        c = classify_cop0(w) or ('cache' if w >> 26 == 0x2F else None)   # N64Recomp ne traduit pas 'cache' non plus
        if c:
            va = tv + i * 4
            fs = max((s for s in starts if s <= va), default=None)
            kern.setdefault(fs, set()).add(c)
    with open(os.path.join(a.out, 'kernel_candidates.txt'), 'w') as f:
        for fs, ins in sorted(kern.items(), key=lambda kv: (kv[0] is None, kv[0])):
            f.write('%s: %s\n' % ('func_%08X' % fs if fs else '(avant la 1ere fonction)', ', '.join(sorted(ins))))

    print(f"Code:  ROM 0x{seg['text']['rom']:X}..0x{seg['text']['rom'] + len(text):X} -> 0x{tv:08X}..0x{tend:08X}  ({tpath})")
    print(f"Image memoire: 0x{IMG_BASE:08X}..0x{img_end:08X} ({len(image) >> 10} Ko), pour les tables de sauts  ({ipath})")
    print(f"Amorce: ROM 0x200..0x1200 -> 0x80001000  ({spath})")
    print(f"Fonctions (graines): {len(ts)} dans le code, {len(ss)} dans le crt0")
    print(f"main = 0x{MAIN:08X}: {'present' if MAIN in set(starts) else 'ABSENT'} parmi les graines")
    print(f"Candidates noyau dans le code du jeu: {len(kern)}")
    for fs, ins in sorted(kern.items(), key=lambda kv: (kv[0] is None, kv[0])):
        print(f"  {'func_%08X' % fs if fs else '?'}: {', '.join(sorted(ins))}")
    print(f"Ecrit dans {a.out}")


if __name__ == '__main__':
    main()
