"""Sections a recompiler pour Samurai Shodown 64 (a copier sur tools/sections.py du fork ReBuriki).

Memes conventions que tools/sections.py de ReBuriki. La carte vient du crt0 de la ROM (voir extract_sams64.py):
  .text  code du jeu       ROM 0x5360..0xA3E60  -> 0x800C0000..0x8015EB00   (copie du crt0)
  .stub  amorce / crt0     ROM 0x200..          -> 0x80001000               (copie du BIOS)
Pas de section .bios pour l'instant: le crt0 met a zero 0x80004000.. (la ou ReBuriki trouve les services BIOS),
donc le jeu ne les appelle probablement pas par la copie en RAM (A VERIFIER au premier demarrage).
Le gestionnaire d'interruptions (0x80000800) n'est PAS recompile: il contient eret/mtc0, il est ecrit a la main.
"""
import os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WORK = os.environ.get('BURIKI_WORK') or os.path.join(ROOT, 'work')


def p(*parts):
    return os.path.join(ROOT, *parts)


def w(name):
    return os.path.join(WORK, name)


SECTIONS = [
    # L'image commence aux donnees (0x8006AA00) et couvre le code et les donnees apres lui: N64Recomp lit les tables de
    # sauts a distance fixe de la fonction (voir extract_sams64.py). Seules les fonctions de [lo, hi) sont recompilees.
    dict(name='.text', image=w('sams64_image_8006AA00.bin'), vram=0x8006AA00,
         funcs=p('tools', 'data', 'functions_text_sams64.txt'), extra=None,
         lo=0x800C0000, hi=0x8015EB00),
    dict(name='.stub', image=w('sams64_stub_80001000.bin'), vram=0x80001000,
         funcs=p('tools', 'data', 'functions_stub_sams64.txt'), extra=None,
         lo=0x80001000, hi=0x800012D8),
    # 9 petites fonctions apres le gestionnaire d'exceptions (sauvegarde FPU/registres, masque Status). Pas le gestionnaire.
    dict(name='.low', image=w('sams64_low_80000800.bin'), vram=0x80000800,
         funcs=p('tools', 'data', 'functions_low_sams64.txt'), extra=None,
         lo=0x80000A98, hi=0x80000CE8),
]

COMBINED_ROM = w('recomp_rom.bin')
