#!/usr/bin/env python3
"""
Audit du code traduit: ce qui fera echouer le jeu plus tard, avant de le lancer.

    python3 audit_sams64.py --fork ~/SamuRecomp

1. sauts indirects (jr reg, reg != ra) que N64Recomp a traduits en appel de fonction: ce sont des 'switch' non reconnus
   (cause du [FATAL] indirect call vers le milieu d'une fonction). Chacun est liste avec sa fonction.
2. mots de donnees qui ressemblent a un pointeur de code mais ne visent aucun debut de fonction connu, avec la
   fonction qui les contient (cibles de tables de sauts reconnues ou debuts de fonctions manquants).
3. appels indirects (jalr) par fonction: ce sont les endroits ou un debut de fonction manquant fait echouer le jeu.
"""
import argparse
import collections
import os
import re
import struct
import sys

CODE_LO, CODE_HI = 0x800C0000, 0x8015EB00
IMG_BASE = 0x8006AA00


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fork", required=True)
    a = ap.parse_args()
    fork = os.path.abspath(os.path.expanduser(a.fork))
    gen = os.path.join(fork, "recomp", "generated")
    starts = {int(m, 16) for m in re.findall(r'name = "func_([0-9A-F]{8})"', open(os.path.join(fork, "recomp", "sams64.syms.toml")).read())}
    ordered = sorted(starts)
    import bisect

    def owner(addr):
        i = bisect.bisect_right(ordered, addr) - 1
        return ordered[i] if i >= 0 else None

    # 1 + 3: parcours du code C
    tail, calls = [], collections.Counter()
    fre = re.compile(r"^RECOMP_FUNC void func_([0-9A-F]{8})\(")
    for f in sorted(os.listdir(gen)):
        if not (f.startswith("funcs_") and f.endswith(".c")):
            continue
        lines = open(os.path.join(gen, f), encoding="utf-8", errors="replace").read().split("\n")
        cur, last_jr = None, None
        for i, l in enumerate(lines):
            m = fre.match(l)
            if m:
                cur = int(m.group(1), 16)
                continue
            m = re.match(r"\s*// (0x[0-9A-F]{8}): (jr|jalr)\s+\$(\w+)", l)
            if m:
                last_jr = (m.group(1), m.group(2), m.group(3))
            if "LOOKUP_FUNC(" in l:
                nxt = " ".join(lines[i + 1:i + 3])
                is_call = "goto after_" in nxt
                if is_call:
                    calls[cur] += 1
                else:
                    tail.append((cur, last_jr, f"{f}:{i + 1}"))

    print("=== 1. sauts indirects traduits en appel de fonction (switch non reconnus) ===")
    if not tail:
        print("  aucun")
    for cur, jr, where in tail:
        print(f"  func_{cur:08X}  {jr[0] + ' ' + jr[1] + ' $' + jr[2] if jr else '?'}  ({where})")

    # 2: pointeurs dans les donnees
    img_path = os.path.join(fork, "work", "sams64_image_8006AA00.bin")
    img = open(img_path, "rb").read()
    n = len(img) // 4
    words = struct.unpack(">%dI" % n, img[:n * 4])
    zone = collections.defaultdict(list)
    for i, w in enumerate(words):
        if CODE_LO <= w < CODE_HI and w % 4 == 0 and w not in starts:
            zone[owner(w)].append((IMG_BASE + i * 4, w))
    print("\n=== 2. pointeurs de donnees vers le code qui ne sont pas des debuts de fonction ===")
    tot = sum(len(v) for v in zone.values())
    print(f"  {tot} mots, dans {len(zone)} fonctions (a l'interieur desquelles ils tombent)")
    print("  (tables de sauts reconnues par N64Recomp: normal. Un mot isole ou une suite qui tombe juste apres un 'jr ra'")
    print("   est un debut de fonction manquant.)")
    for fs, lst in sorted(zone.items(), key=lambda kv: -len(kv[1]))[:25]:
        print(f"  dans func_{fs:08X}: {len(lst)} pointeur(s), p.ex. {lst[0][1]:08X} (a {lst[0][0]:08X})")

    print("\n=== 3. appels indirects (jalr) par fonction (les plus nombreux) ===")
    print(f"  {sum(calls.values())} appels dans {len(calls)} fonctions")
    for fs, c in calls.most_common(10):
        print(f"  func_{fs:08X}: {c}")


if __name__ == "__main__":
    main()
