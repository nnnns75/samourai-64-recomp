#!/usr/bin/env python3
"""Renomme l'interface en "Samurai Shodown 64" (titre de fenetre, titre du menu, messages d'erreur,
commentaires des fichiers de reglages, fichier journal samurecomp.log). Idempotent, remplacements exacts.
Usage: python3 rename_sams64.py --fork ~/SamuRecomp   puis recompiler (4 fichiers .cpp, rapide)."""
import argparse, os, sys

ap = argparse.ArgumentParser(); ap.add_argument("--fork", required=True); a = ap.parse_args()
rt = os.path.join(os.path.abspath(os.path.expanduser(a.fork)), "recomp", "runtime")
NAME, UP = "Samurai Shodown 64", "SAMURAI SHODOWN 64"

EDITS = {
    "frontend/fe_window.cpp": [('"BurikiRecomp", "Buriki One"', '"BurikiRecomp", "%s"' % NAME)],
    "frontend/menu.cpp": [('"BURIKI ONE");', '"%s");' % UP)],
    "frontend/fe_input.cpp": [("# Buriki One controls", "# %s controls" % NAME)],
    "frontend/settings.cpp": [("# Buriki One settings", "# %s settings" % NAME)],
    "main.cpp": [
        ('std::string("Buriki One has to stop:\\n\\n")', 'std::string("%s has to stop:\\n\\n")' % NAME),
        ("The details are in buriki.log, in the game's folder.", "The details are in samurecomp.log, in the game's folder."),
        ('MessageBoxA(nullptr, text.c_str(), "Buriki One"', 'MessageBoxA(nullptr, text.c_str(), "%s"' % NAME),
        ('exe_dir() + "buriki.log", old = exe_dir() + "buriki.old.log"', 'exe_dir() + "samurecomp.log", old = exe_dir() + "samurecomp.old.log"'),
    ],
}
for rel, edits in EDITS.items():
    p = os.path.join(rt, rel)
    t = open(p, encoding="utf-8").read()
    for old, new in edits:
        if new in t:
            continue
        if t.count(old) != 1:
            sys.exit("erreur: %s: motif %r trouve %d fois (attendu 1)" % (rel, old, t.count(old)))
        t = t.replace(old, new)
    open(p, "w", encoding="utf-8", newline="\n").write(t)
    print("OK:", rel)
