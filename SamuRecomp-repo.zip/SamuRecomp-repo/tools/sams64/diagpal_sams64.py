#!/usr/bin/env python3
"""
Diagnostic palette: a l'image demandee (env BURIKI_SPRITES=N), affiche pour chacune des 16 tranches de 256 entrees de la
palette le nombre d'entrees non nulles et les 6 premieres couleurs non nulles. Sans effet sur le rendu.

    python3 diagpal_sams64.py --fork ~/SamuRecomp      (puis recompiler)
"""
import argparse
import os
import sys

OLD = '''    fprintf(stderr, "\\n");
    for (int i = 0; i < (0xc000 / 4) / 8; i++) {'''
NEW = '''    fprintf(stderr, "\\n");
    for (int bank = 0; bank < 16; bank++) {   // DIAGPAL
        int nz = 0, shown = 0;
        char buf[256] = {};
        for (int i = 0; i < 256; i++) {
            const u32 c = m_paletteram[bank * 256 + i];
            if (c & 0xffffff) {
                nz++;
                if (shown < 6) { snprintf(buf + strlen(buf), sizeof(buf) - strlen(buf), " %02X:%06X", i, c & 0xffffff); shown++; }
            }
        }
        fprintf(stderr, "[DIAGPAL %u] banque %X (entrees %03X-%03X): %d non nulles%s\\n", f, bank, bank * 256, bank * 256 + 255, nz, buf);
    }
    for (int i = 0; i < (0xc000 / 4) / 8; i++) {'''


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fork", required=True)
    a = ap.parse_args()
    p = os.path.join(os.path.abspath(os.path.expanduser(a.fork)), "recomp", "runtime", "video.cpp")
    t = open(p, encoding="utf-8").read()
    if "DIAGPAL" in t:
        print("deja applique")
        return
    if t.count(OLD) != 1:
        sys.exit(f"erreur: motif trouve {t.count(OLD)} fois (attendu 1)")
    open(p, "w", encoding="utf-8", newline="\n").write(t.replace(OLD, NEW))
    print("OK: diagnostic palette ajoute (video.cpp)")


if __name__ == "__main__":
    main()
