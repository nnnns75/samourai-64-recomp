#!/usr/bin/env python3
"""
Pourquoi une fonction n'est-elle jamais appelee ? Remonte ses appelants dans le code traduit, indique lesquels ont ete
executes (fichier de couverture du runtime) et affiche le code MIPS qui precede chaque appel depuis un appelant execute.

    python3 whynot_sams64.py --fork ~/SamuRecomp --cov ~/cov.txt --target func_800CF7B4 [--depth 3] [--lines 40]
"""
import argparse
import os
import re
import sys

FRE = re.compile(r"^RECOMP_FUNC void (func_[0-9A-F]{8})\(")
CALL = re.compile(r"\b(func_[0-9A-F]{8})\(rdram, ctx\);")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fork", required=True)
    ap.add_argument("--cov", required=True)
    ap.add_argument("--target", required=True, action="append")
    ap.add_argument("--depth", type=int, default=3)
    ap.add_argument("--lines", type=int, default=40)
    a = ap.parse_args()
    gen = os.path.join(os.path.abspath(os.path.expanduser(a.fork)), "recomp", "generated")
    covered = {l.strip() for l in open(os.path.expanduser(a.cov)) if l.strip()}
    body, callers = {}, {}
    for f in sorted(os.listdir(gen)):
        if not (f.startswith("funcs_") and f.endswith(".c")):
            continue
        cur = None
        for l in open(os.path.join(gen, f), encoding="utf-8", errors="replace"):
            m = FRE.match(l)
            if m:
                cur = m.group(1)
                body[cur] = []
                continue
            if cur:
                body[cur].append(l.rstrip("\n"))
                for c in CALL.findall(l):
                    callers.setdefault(c, []).append((cur, len(body[cur]) - 1))
    print(f"{len(covered)} fonctions executees, {len(body)} fonctions traduites\n")

    def show(func, idx, n):
        out = []
        for l in body[func][max(0, idx - 4 * n):idx + 1]:
            s = l.strip()
            if s.startswith("// 0x") or re.match(r"L_[0-9A-F]+:", s) or "goto" in s or re.search(r"func_[0-9A-F]{8}\(", s):
                out.append("      " + s)
        return "\n".join(out[-n:])

    seen = set()

    def walk(t, depth, indent=""):
        if t in seen:
            return
        seen.add(t)
        status = "EXECUTEE" if t in covered else "jamais executee"
        cs = callers.get(t, [])
        print(f"{indent}{t}: {status}; {len(cs)} appel(s) direct(s) dans le code")
        if not cs:
            print(f"{indent}  (aucun appelant direct: appel par pointeur, table de donnees ou adresse construite)")
        for c, idx in cs:
            st = "EXECUTE" if c in covered else "jamais execute"
            print(f"{indent}  <- {c} ({st})")
            if c in covered and t not in covered:
                print(f"{indent}     code avant l'appel dans {c}:")
                print(show(c, idx, a.lines))
        if t not in covered and depth > 0:
            for c, _ in cs:
                if c not in covered:
                    walk(c, depth - 1, indent + "    ")

    for t in a.target:
        walk(t, a.depth)
        print()


if __name__ == "__main__":
    main()
