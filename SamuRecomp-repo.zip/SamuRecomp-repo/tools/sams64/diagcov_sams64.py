#!/usr/bin/env python3
"""
Couverture: avec BURIKI_COVERAGE=fichier, le runtime ecrit a l'arret la liste des fonctions du jeu entrees au moins une fois.
Ne coute rien sans la variable.

    python3 diagcov_sams64.py --fork ~/SamuRecomp      (prerequis: diagwatch_sams64.py deja applique; puis recompiler hw.cpp)
"""
import argparse
import os
import sys


def rep(t, old, new, what):
    if t.count(old) != 1:
        sys.exit(f"erreur: {what}: motif trouve {t.count(old)} fois (attendu 1)")
    return t.replace(old, new)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fork", required=True)
    a = ap.parse_args()
    p = os.path.join(os.path.abspath(os.path.expanduser(a.fork)), "recomp", "runtime", "hw.cpp")
    c = open(p, encoding="utf-8").read()
    if "DIAGCOV" in c:
        print("deja applique")
        return
    if "DIAGWATCH" not in c:
        sys.exit("erreur: appliquer d'abord diagwatch_sams64.py")
    c = rep(c, '#include "kernel_sams64.h"\n', '#include "kernel_sams64.h"\n#include <unordered_set>   // DIAGCOV\n#include <set>\n', "include")
    c = rep(c, "int g_watch_on = 0;\n", "int g_watch_on = 0;\nstatic std::string g_cov_path;   // DIAGCOV\nstatic std::set<std::string> g_cov;\n", "etat")
    c = rep(c, "    if (!g_watch_on) return;\n    for (auto& w : watches())",
            '    if (!g_watch_on) return;\n    if (!g_cov_path.empty()) {\n        if (FILE* f = fopen(g_cov_path.c_str(), "w")) { for (auto& n : g_cov) fprintf(f, "%s\\n", n.c_str()); fclose(f); }\n'
            '        fprintf(stderr, "[coverage] %zu fonctions entrees -> %s\\n", g_cov.size(), g_cov_path.c_str());\n    }\n    for (auto& w : watches())', "rapport")
    c = rep(c, "void hw_watch_func(const char* name) {\n",
            "void hw_watch_func(const char* name) {\n    if (!g_cov_path.empty()) { static std::unordered_set<const char*> seen; if (seen.insert(name).second) g_cov.insert(name); }\n", "entree")
    c = rep(c, "    const char* e = getenv(\"BURIKI_CALLWATCH\");\n    if (!e) return;\n",
            "    if (const char* o = getenv(\"BURIKI_COVERAGE\")) { g_cov_path = o; g_watch_on = 1; }\n    const char* e = getenv(\"BURIKI_CALLWATCH\");\n    if (!e) return;\n", "init")
    open(p, "w", encoding="utf-8", newline="\n").write(c)
    print("OK: couverture ajoutee (hw.cpp)")


if __name__ == "__main__":
    main()
