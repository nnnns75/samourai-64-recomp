#!/usr/bin/env python3
"""Neutralise les options de ReBuriki qui dependent d'adresses memoire de Buriki One (a ne pas appliquer
a Samurai Shodown 64): "Unlock Silber" (nvram+0x20F0, RAM 0xF3990), options d'arcade (nvram 0x2030/0x2050 <->
RAM 0x801446E0/F0: difficulte, free play, sang...) et le jeu en ligne (WAIT_SP 0x803FFFC0). Elles restent
visibles mais grisees dans le menu et n'ecrivent plus rien. Le reste (affichage, son, manette, region...) est inchange.
Usage: python3 options_sams64.py --fork ~/SamuRecomp   puis recompiler. Idempotent."""
import argparse, os, sys

ap = argparse.ArgumentParser(); ap.add_argument("--fork", required=True); a = ap.parse_args()
rt = os.path.join(os.path.abspath(os.path.expanduser(a.fork)), "recomp", "runtime")

EDITS = {
    "hw.cpp": [
        ("void hw_set_unlock_silber(bool on) {\n    g_unlock_silber = on;\n    if (!g_ram) return;",
         "void hw_set_unlock_silber(bool on) {\n    (void)on; g_unlock_silber = false;   // Buriki One only (SS64: rien a debloquer); SAMS64\n    return;\n    if (!g_ram) return;"),
        ("bool hw_game_options_ready(void) {\n    if (!g_ram) return false;",
         "bool hw_game_options_ready(void) {\n    return false;   // adresses de Buriki One: pas encore cartographiees pour SS64; SAMS64\n    if (!g_ram) return false;"),
    ],
    "frontend/settings.cpp": [("s->unlock_silber = 1;", "s->unlock_silber = 0;")],
    "frontend/menu.cpp": [
        ("static int offline(void) { return !H->online_active(); }",
         "static int offline(void) { return !H->online_active(); }\nstatic int never(void) { return 0; }   // SAMS64: fonction propre a Buriki One, grisee"),
        ("get_unlock_silber, set_unlock_silber, offline)", "get_unlock_silber, set_unlock_silber, never)"),
        ("act_host, offline)", "act_host, never)"),
        ("get_address, set_address, offline)", "get_address, set_address, never)"),
        ("act_join, can_join)", "act_join, never)"),
        ("get_online_delay, set_online_delay, k_delay, offline)", "get_online_delay, set_online_delay, k_delay, never)"),
        ('"Experimental. Two players over the internet or a home network, each on their own PC."',
         '"Not available yet for Samurai Shodown 64 (needs this game\'s own memory addresses)."'),
    ],
}
for rel, edits in EDITS.items():
    p = os.path.join(rt, rel)
    t = open(p, encoding="utf-8").read()
    for old, new in edits:
        if new in t:
            continue
        if t.count(old) != 1:
            sys.exit("erreur: %s: motif %r trouve %d fois (attendu 1)" % (rel, old[:60], t.count(old)))
        t = t.replace(old, new)
    open(p, "w", encoding="utf-8", newline="\n").write(t)
    print("OK:", rel)
