#!/usr/bin/env python3
"""Correctif: registre vblank tcram+0x48 = 0xFFFFFFFF pendant le vblank (comme MAME), au lieu de 1.
Sans cela Samurai Shodown 64 ne copie jamais ses palettes (func_800C52C4 exige lhu(tcram+0x4A)==0xFFFF).
Usage: python3 fix_vblank_sams64.py --fork ~/SamuRecomp   (puis recompiler: seul hw.cpp change). Idempotent."""
import argparse, os, sys
ap = argparse.ArgumentParser(); ap.add_argument("--fork", required=True); a = ap.parse_args()
p = os.path.join(os.path.abspath(os.path.expanduser(a.fork)), "recomp", "runtime", "hw.cpp")
t = open(p, encoding="utf-8").read()
new = "case 0x20208048: v = g_in_vblank ? 0xFFFFFFFFu : 0; return true;"
old = "case 0x20208048: v = g_in_vblank ? 1 : 0; return true;"
if new in t:
    print("deja applique"); sys.exit(0)
if t.count(old) != 1:
    sys.exit("erreur: motif attendu 1 fois, trouve %d" % t.count(old))
open(p, "w", encoding="utf-8", newline="\n").write(t.replace(old, new))
print("OK: vblank = 0xFFFFFFFF dans hw.cpp")
