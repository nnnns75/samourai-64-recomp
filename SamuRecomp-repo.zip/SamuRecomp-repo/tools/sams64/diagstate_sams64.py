#!/usr/bin/env python3
"""Diagnostic: journalise les changements d'etat de func_80113200 (machine a etats).
Usage: python3 diagstate_sams64.py --fork ~/SamuRecomp [--func func_80113200]
Ajoute dans le C genere un fprintf: [STATE] a0=... state=... cd=... (a chaque changement).
Idempotent. Les fichiers generes sont ecrases a la retraduction: relancer ensuite."""
import argparse, glob, os, re, sys

ap = argparse.ArgumentParser()
ap.add_argument("--fork", required=True)
ap.add_argument("--func", default="func_80113200")
a = ap.parse_args()

gen = os.path.join(os.path.expanduser(a.fork), "recomp", "generated")
pat = re.compile(r"^RECOMP_FUNC void %s\(.*\{\s*$" % re.escape(a.func), re.M)
for f in sorted(glob.glob(os.path.join(gen, "funcs_*.c"))):
    s = open(f, encoding="utf-8", errors="replace").read()
    m = pat.search(s)
    if not m:
        continue
    if "DIAGSTATE" in s[m.start():m.start() + 600]:
        print("deja applique:", f)
        sys.exit(0)
    probe = (
        "\n    { /* DIAGSTATE */ static uint32_t last = 0xFFFFFFFFu; static int n = 0;"
        " uint32_t st = (uint32_t)MEM_W(ctx->r4, 0x40);"
        " if (st != last) { fprintf(stderr, \"[STATE] a0=%%08X state=%%u (appel %%d) cd=%%d\\n\","
        " (uint32_t)ctx->r4, st, n, (int)MEM_W(ctx->r28, -0x2340)); last = st; } n++; }"
    ).replace("%%", "%")
    s = s[:m.start()] + "#include <cstdio>\n" + s[m.start():m.end()] + probe + s[m.end():]
    open(f, "w", encoding="utf-8").write(s)
    print("OK:", f)
    sys.exit(0)
print("fonction introuvable:", a.func)
sys.exit(1)
