#!/usr/bin/env python3
"""
Adapte le runtime ReBuriki (dans ton fork) a Samurai Shodown 64.

    python3 apply_sams64_patch.py --fork ~/SamuRecomp --kit ~/Downloads/files

Chaque remplacement verifie que le texte d'origine est present EXACTEMENT une fois (sinon arret, rien n'est ecrit
a moitie: tout est valide en memoire avant la premiere ecriture). Relancer le script sur un fork deja patche est sans effet.
"""
import argparse
import os
import shutil
import sys


def rep(text, old, new, what):
    n = text.count(old)
    if n != 1:
        sys.exit(f"erreur: {what}: motif trouve {n} fois (attendu 1). Le fork n'est pas celui que le patch attend.")
    return text.replace(old, new)


def patch_hw(t):
    t = rep(t, '#include "funcs.h"\n', '#include "funcs.h"\n#include "kernel_sams64.h"\n', "hw.cpp include")
    t = rep(t, 'const char* pairs[3][2] = {{"007pr01b.81", "007pr02b.82"}, {"007pr03a.83", "007pr04a.84"}, {"007pr05a.85", "007pr06a.86"}};\n    for (int p = 0; p < 3; p++) {',
            'const char* pairs[2][2] = {{"002-pro1a.81", "002-pro2a.82"}, {"002-pro3a.83", "002-pro4a.84"}};   // Samurai Shodown 64: 2 x 8 MB\n    for (int p = 0; p < 2; p++) {',
            "hw.cpp paires de ROM programme")
    t = rep(t, 'dir + "/buriki/" + pairs[p][0]', 'dir + "/sams64/" + pairs[p][0]', "hw.cpp dossier lo")
    t = rep(t, 'dir + "/buriki/" + pairs[p][1]', 'dir + "/sams64/" + pairs[p][1]', "hw.cpp dossier hi")
    t = rep(t, '        func_800C2B20(rdram, ctx);\n', '        sams_irq_dispatch(rdram, ctx);   // gestionnaire d\'exception ROM 0x80000800, voie interruption\n', "hw.cpp irq")
    # registre d'etat vblank (tcram+0x48): MAME le declare PORT_BIT(0xffffffff) -> 0xFFFFFFFF pendant le vblank.
    # Samurai Shodown 64 teste lhu(+0x4A)==0xFFFF avant de copier ses palettes (func_800C52C4); Buriki tolere "1".
    t = rep(t, "case 0x20208048: v = g_in_vblank ? 1 : 0; return true;", "case 0x20208048: v = g_in_vblank ? 0xFFFFFFFFu : 0; return true;", "hw.cpp vblank 0xFFFFFFFF")
    return t


def patch_main(t):
    return rep(t, '    func_80008000(g_ram, &g_ctx);\n', '    func_80001000(g_ram, &g_ctx);   // point d\'entree SS64: le 1er bloc de 4 Ko copie par le BIOS (ROM 0x200)\n', "main.cpp entree")


def patch_video(t):
    a = t.index('    std::string d = std::string(rom_dir) + "/buriki/";\n    g_scrtile.assign')
    b = t.index('    auto mk = [](const std::vector<u8>& r')
    new = '''    std::string d = std::string(rom_dir) + "/sams64/";
    // Samurai Shodown 64: scroll 32 MB, sprites 32 MB (MAME ROM_START(sams64)).
    g_scrtile.assign(0x2000000, 0);
    load_interleaved(g_scrtile, d + "002-sc01a.41", 0x0000000, 2);
    load_interleaved(g_scrtile, d + "002-sc02a.42", 0x0000001, 2);
    load_interleaved(g_scrtile, d + "002-sc05a.45", 0x0800000, 2);
    load_interleaved(g_scrtile, d + "002-sc06a.46", 0x0800001, 2);
    load_interleaved(g_scrtile, d + "002-sc03a.43", 0x1000000, 2);
    load_interleaved(g_scrtile, d + "002-sc04a.44", 0x1000001, 2);
    load_interleaved(g_scrtile, d + "002-sc07a.47", 0x1800000, 2);
    load_interleaved(g_scrtile, d + "002-sc08a.48", 0x1800001, 2);
    hng64_reorder(g_scrtile);

    g_sprtile.assign(0x2000000, 0);
    const char* sp[8] = {"002-sp01a.53", "002-sp02a.54", "002-sp03a.55", "002-sp04a.56",
                         "002-sp05a.57", "002-sp06a.58", "002-sp07a.59", "002-sp08a.60"};
    for (int i = 0; i < 8; i++) load_interleaved(g_sprtile, d + sp[i], (i < 4 ? 0 : 0x1000000) + (i & 3), 4);

'''
    t = t[:a] + new + t[b:]
    t = rep(t, 'std::vector<u8> g_scrtile;   // 64 MB', 'std::vector<u8> g_scrtile;   // (SS64: 32 MB; Buriki: 64 MB)', "video.cpp commentaire") if 'std::vector<u8> g_scrtile;   // 64 MB' in t else t
    return t


def patch_video3d(t):
    t = rep(t, 'std::string d = std::string(rom_dir) + "/buriki/";\n    auto read =', 'std::string d = std::string(rom_dir) + "/sams64/";\n    auto read =', "video3d.cpp dossier")
    t = rep(t, 'const char* tx[4] = {"007tx01a.1", "007tx02a.2", "007tx03a.3", "007tx04a.4"};', 'const char* tx[4] = {"002-tx01a.1", "002-tx02a.2", "002-tx03a.3", "002-tx04a.4"};', "video3d.cpp textures")
    old = t[t.index('    const char* vt[3] = {'):t.index('    // MAME machine_start: texture wrap')]
    new = '''    // SS64: 6 puces de vertex. ROM_REGION16_LE 0x1800000 (octets): vt01-03 a l'octet 0, vt04-06 a l'octet 0xC00000
    // (mot 0x600000), chacune en ROM_GROUPWORD | ROM_SKIP(4): un mot de 16 bits de chaque puce a tour de role.
    const char* vt[6] = {"002-vt01a.17", "002-vt02a.18", "002-vt03a.19", "002-vt04a.20", "002-vt05a.21", "002-vt06a.22"};
    m_vertsrom.assign(0x1800000 / 2, 0);
    for (int g = 0; g < 2; g++)
        for (int c = 0; c < 3; c++) {
            auto v = read(d + vt[g * 3 + c]);
            for (size_t w = 0; w < v.size() / 2; w++) m_vertsrom[(size_t)g * 0x600000 + w * 3 + c] = (u16)(v[w * 2] | v[w * 2 + 1] << 8);
        }

'''
    return t.replace(old, new)


def patch_sound(t):
    t = rep(t, 'const char* sd[4] = {"007sd01a.77", "007sd02a.78", "007sd03a.79", "007sd04a.80"};\n    for (int i = 0; i < 4; i++) {',
            'const char* sd[3] = {"002-sd01a.77", "002-sd02a.78", "002-sd03a.79"};   // SS64: 3 x 4 MB (le reste de la region reste a 0)\n    for (int i = 0; i < 3; i++) {', "sound.cpp fichiers")
    return rep(t, '"/buriki/" + sd[i]', '"/sams64/" + sd[i]', "sound.cpp dossier")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fork", required=True)
    ap.add_argument("--kit", required=True, help="dossier du kit (contient runtime/kernel_sams64.*)")
    a = ap.parse_args()
    rt = os.path.join(a.fork, "recomp", "runtime")
    plan = {"hw.cpp": patch_hw, "main.cpp": patch_main, "video.cpp": patch_video,
            "video3d.cpp": patch_video3d, "sound.cpp": patch_sound}
    out = {}
    for name, fn in plan.items():
        p = os.path.join(rt, name)
        t = open(p, encoding="utf-8").read()
        if "sams_irq_dispatch" in t or '"/sams64/' in t or "func_80001000(g_ram" in t:
            print(f"{name}: deja patche")
            continue
        out[p] = fn(t)
    toml = os.path.join(a.fork, "recomp", "sams64.toml")
    tt = open(toml, encoding="utf-8").read()
    if '#include \\"kernel.h\\"' in tt:
        out[toml] = tt.replace('#include \\"kernel.h\\"', '#include \\"kernel_sams64.h\\"')
    src = {}
    for f in ("kernel_sams64.h", "kernel_sams64.cpp"):
        for d in (os.path.join(a.kit, "runtime"), a.kit, os.path.dirname(os.path.abspath(__file__))):
            if os.path.exists(os.path.join(d, f)):
                src[f] = os.path.join(d, f)
                break
        else:
            sys.exit(f"erreur: {f} introuvable (cherche dans {a.kit}/runtime et {a.kit}). Telecharge-le puis relance.")
    for p, t in out.items():
        open(p, "w", encoding="utf-8", newline="\n").write(t)
    for f in ("kernel_sams64.h", "kernel_sams64.cpp"):
        shutil.copyfile(src[f], os.path.join(rt, f))
    # kernel.cpp de Buriki redefinit des noms de fonctions generees: on le retire.
    # kernel.h devient un en-tete de renvoi (tools/make_func_table.py l'inclut encore).
    kc = os.path.join(rt, "kernel.cpp")
    if os.path.exists(kc):
        os.rename(kc, kc + ".buriki")
    with open(os.path.join(rt, "kernel.h"), "w") as f:
        f.write('// SS64: le noyau ecrit a la main est dans kernel_sams64.h (kernel.cpp de Buriki retire).\n#include "kernel_sams64.h"\n')
    print("OK: runtime adapte a Samurai Shodown 64 (" + ", ".join(os.path.basename(p) for p in out) + ")")


if __name__ == "__main__":
    main()
