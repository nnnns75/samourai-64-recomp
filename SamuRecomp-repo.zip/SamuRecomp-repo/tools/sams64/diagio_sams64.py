#!/usr/bin/env python3
"""Diagnostic: journalise les messages 8 octets de la carte I/O recus par func_800C1F70
(apres l'appel a func_800C2400). Affiche [IOMSG] b0..b7 a chaque nouveau message (80 max).
Usage: python3 diagio_sams64.py --fork ~/SamuRecomp   (puis rebuild). Idempotent."""
import argparse, glob, os, re, sys

ap = argparse.ArgumentParser()
ap.add_argument("--fork", required=True)
a = ap.parse_args()
gen = os.path.join(os.path.expanduser(a.fork), "recomp", "generated")

PROBE = (
    '    { /* DIAGIO */ static uint8_t last[8]; static int n = 0; uint8_t cur[8];'
    ' for (int i = 0; i < 8; i++) cur[i] = (uint8_t)MEM_BU(ctx->r28, -0x2798 + i);'
    ' if ((uint32_t)ctx->r2 != 0 && memcmp(cur, last, 8) != 0 && n < 80) { n++; memcpy(last, cur, 8);'
    ' fprintf(stderr, "[IOMSG] %02X %02X %02X %02X %02X %02X %02X %02X\\n",'
    ' cur[0], cur[1], cur[2], cur[3], cur[4], cur[5], cur[6], cur[7]); } }'
)

for f in sorted(glob.glob(os.path.join(gen, "funcs_*.c"))):
    s = open(f, encoding="utf-8", errors="replace").read()
    m = re.search(r"^RECOMP_FUNC void func_800C1F70\(.*\{\s*$", s, re.M)
    if not m:
        continue
    if "DIAGIO" in s:
        print("deja applique:", f); sys.exit(0)
    nxt = re.search(r"^RECOMP_FUNC void func_", s[m.end():], re.M)
    end = m.end() + (nxt.start() if nxt else len(s) - m.end())
    body = s[m.end():end]
    c = re.search(r"^\s*func_800C2400\(rdram, ctx\);\s*$", body, re.M)
    if not c:
        sys.exit("appel a func_800C2400 introuvable dans func_800C1F70")
    body = body[:c.end()] + "\n" + PROBE + body[c.end():]
    s = "#include <cstdio>\n#include <cstring>\n" + s[:m.end()] + body + s[end:]
    open(f, "w", encoding="utf-8").write(s)
    print("OK:", f); sys.exit(0)
sys.exit("func_800C1F70 introuvable")
