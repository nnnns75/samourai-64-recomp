"""Noms du produit pour le portage Samurai Shodown 64 (a copier sur tools/install/product.py du fork)."""
PRODUCT = "SamuRecomp"                      # TODO: nom de ton choix
GAME = "Samurai Shodown 64"
EXE = "SamuRecomp.exe"
VERSION = "0.0.1"
PUBLISHER = "TODO"
DESCRIPTION = "%s (%s PC port)" % (PRODUCT, GAME)
COPYRIGHT = "%s code: see the licenses folder. %s is a trademark of its owners." % (PRODUCT, GAME)
