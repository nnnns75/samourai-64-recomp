#!/usr/bin/env python3
"""
Diagnostic 3D: fait afficher par le runtime (une seule fois chacun) les types de blocs de polygones et les
paquets 3D qu'il ne connait pas, et le nombre de lectures de geometrie hors ROM.

    python3 diag3d_sams64.py --fork ~/SamuRecomp      (puis recompiler; sans effet sur le rendu)
"""
import argparse
import os
import sys


def rep(t, old, new, what):
    if t.count(old) != 1:
        sys.exit(f"erreur: {what}: motif trouve {t.count(old)} fois (attendu 1)")
    return t.replace(old, new)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fork", required=True)
    a = ap.parse_args()
    p = os.path.join(os.path.abspath(os.path.expanduser(a.fork)), "recomp", "runtime", "video3d.cpp")
    t = open(p, encoding="utf-8").read()
    if "DIAG3D" in t:
        print("deja applique")
        return
    t = rep(t, "            default:\n                chunkLength = counter;\n                break;\n            }\n",
            "            default:\n                { static bool seen[256]; if (!seen[chunkType]) { seen[chunkType] = true; fprintf(stderr, \"[DIAG3D] type de bloc inconnu 0x%02X (frame %u)\\n\", chunkType, hw_frame_number()); } }\n"
            "                chunkLength = counter;\n                break;\n            }\n", "bloc inconnu")
    t = rep(t, "    default: break;   // 0x1000 / 0x1001: unknown global flags\n",
            "    default: { static bool seen[65536]; if (!seen[packet[0]]) { seen[packet[0]] = true; fprintf(stderr, \"[DIAG3D] paquet 3D 0x%04X ignore (frame %u)\\n\", packet[0], hw_frame_number()); } break; }   // 0x1000 / 0x1001: unknown global flags\n", "paquet inconnu")
    t = rep(t, "// Display list upload trigger (write to 0x20300200): run the 16 packets at 0x20300000.\nextern \"C\" void video3d_dl_upload(uint32_t data) {\n",
            "// Display list upload trigger (write to 0x20300200): run the 16 packets at 0x20300000.\nextern \"C\" void video3d_dl_upload(uint32_t data) {\n"
            "    { static uint64_t last = 0; if (hw_frame_number() % 500 == 0 && g_bad_geometry != last) { last = g_bad_geometry; fprintf(stderr, \"[DIAG3D] geometrie hors ROM: %llu (frame %u)\\n\", (unsigned long long)g_bad_geometry, hw_frame_number()); } }\n", "upload")
    open(p, "w", encoding="utf-8", newline="\n").write(t)
    print("OK: diagnostics 3D ajoutes (video3d.cpp)")


if __name__ == "__main__":
    main()
