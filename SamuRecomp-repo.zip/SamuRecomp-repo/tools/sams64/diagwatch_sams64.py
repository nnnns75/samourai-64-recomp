#!/usr/bin/env python3
"""
Diagnostic d'appels: avec BURIKI_CALLWATCH="func_80113200,func_800CF7B4,...", le runtime affiche la 1re entree de chaque
fonction nommee (image, et appelant le plus proche) puis le nombre total d'entrees a l'arret. Sans variable: aucun cout.

    python3 diagwatch_sams64.py --fork ~/SamuRecomp      (puis recompiler)
"""
import argparse
import os
import sys


def rep(t, old, new, what):
    if t.count(old) != 1:
        sys.exit(f"erreur: {what}: motif trouve {t.count(old)} fois (attendu 1)")
    return t.replace(old, new)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fork", required=True)
    a = ap.parse_args()
    rt = os.path.join(os.path.abspath(os.path.expanduser(a.fork)), "recomp", "runtime")
    hp, cp = os.path.join(rt, "hw.h"), os.path.join(rt, "hw.cpp")
    h, c = open(hp, encoding="utf-8").read(), open(cp, encoding="utf-8").read()
    if "DIAGWATCH" in h:
        print("deja applique")
        return
    h = rep(h, "extern uint32_t g_func_ring_pos;\n",
            "extern uint32_t g_func_ring_pos;\nextern int g_watch_on;   // DIAGWATCH\nvoid hw_watch_func(const char* name);\n", "hw.h decl")
    h = rep(h, "    g_func_ring[g_func_ring_pos++ & (HW_FUNC_RING - 1)] = name;\n",
            "    g_func_ring[g_func_ring_pos++ & (HW_FUNC_RING - 1)] = name;\n    if (__builtin_expect(g_watch_on, 0)) hw_watch_func(name);\n", "hw.h hook")
    c = rep(c, "uint32_t hw_frame_number(void) { return g_frame; }\n", '''uint32_t hw_frame_number(void) { return g_frame; }

// DIAGWATCH: BURIKI_CALLWATCH="func_A,func_B": first entry of each (frame + the function that was running before) and totals.
int g_watch_on = 0;
namespace {
struct Watch { std::string name; uint64_t n = 0; };
std::vector<Watch>& watches() { static std::vector<Watch> w; return w; }
}
extern "C++" void hw_watch_report(void) {
    if (!g_watch_on) return;
    for (auto& w : watches()) fprintf(stderr, "[watch-call] %s: %llu entrees\\n", w.name.c_str(), (unsigned long long)w.n);
}
void hw_watch_func(const char* name) {
    for (auto& w : watches())
        if (w.name == name) {
            if (w.n++ == 0) {
                const char* prev = g_func_ring[(g_func_ring_pos - 2) & (HW_FUNC_RING - 1)];
                fprintf(stderr, "[watch-call] %s entree pour la 1re fois a l'image %u (fonction precedente: %s)\\n", name, g_frame, prev ? prev : "?");
            }
            return;
        }
}
static void hw_watch_init() {
    const char* e = getenv("BURIKI_CALLWATCH");
    if (!e) return;
    std::string s = e;
    size_t p = 0;
    while (p < s.size()) { size_t q = s.find(',', p); if (q == std::string::npos) q = s.size(); if (q > p) watches().push_back({s.substr(p, q - p)}); p = q + 1; }
    g_watch_on = !watches().empty();
}
''', "hw.cpp watch")
    c = rep(c, "void hw_init(const HwConfig* cfg) {\n    g_cfg = *cfg;\n", "void hw_init(const HwConfig* cfg) {\n    g_cfg = *cfg;\n    hw_watch_init();\n", "hw_init")
    c = rep(c, '            fprintf(stderr, "[stop] reached %u frames', '            hw_watch_report();\n            fprintf(stderr, "[stop] reached %u frames', "arret")
    open(hp, "w", encoding="utf-8", newline="\n").write(h)
    open(cp, "w", encoding="utf-8", newline="\n").write(c)
    print("OK: diagnostic d'appels ajoute (hw.h, hw.cpp). Le rapport final est dans [watch-call].")


if __name__ == "__main__":
    main()
