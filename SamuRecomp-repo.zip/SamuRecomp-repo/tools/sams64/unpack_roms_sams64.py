#!/usr/bin/env python3
"""
Extrait de TES zips MAME les fichiers dont le portage a besoin, dans <fork>/roms/sams64 et <fork>/roms/hng64.

    python3 unpack_roms_sams64.py --fork ~/SamuRecomp --game sams64.zip --bios hng64.zip

Les fichiers sont retrouves par taille et CRC-32 (pas par nom: un set MAME range les textures identiques sous un seul
nom, ex. 002-tx01a.13 pour 002-tx01a.1), puis ecrits sous le nom canonique que le moteur attend. Les CRC sont ceux de MAME:
si l'un differe, le script s'arrete (autre revision du jeu). Rien de ce qui est ecrit ici ne doit etre publie.
"""
import argparse
import os
import sys
import zipfile
import zlib

GAME_ROMS = [   # (nom, taille, CRC-32) d'apres MAME src/mame/snk/hng64.cpp, ROM_START(sams64); textures: 1 copie sur 4
    ("002-pro1a.81", 0x400000, 0xE5B907C5),
    ("002-pro2a.82", 0x400000, 0x803ED2EB),
    ("002-pro3a.83", 0x400000, 0x582156A7),
    ("002-pro4a.84", 0x400000, 0x5A8291E9),
    ("002-sc01a.41", 0x400000, 0x77C3DF69),
    ("002-sc02a.42", 0x400000, 0x60065174),
    ("002-sc05a.45", 0x400000, 0xFD242BEE),
    ("002-sc06a.46", 0x400000, 0x87AFC297),
    ("002-sc03a.43", 0x400000, 0x5D4A5289),
    ("002-sc04a.44", 0x400000, 0xAA5536FA),
    ("002-sc07a.47", 0x400000, 0xE01E8A95),
    ("002-sc08a.48", 0x400000, 0xA17464D0),
    ("002-sp01a.53", 0x400000, 0xC73CF9B4),
    ("002-sp02a.54", 0x400000, 0x04B0ECC8),
    ("002-sp03a.55", 0x400000, 0x13C80B74),
    ("002-sp04a.56", 0x400000, 0xB1A6A06D),
    ("002-sp05a.57", 0x400000, 0xFA71E825),
    ("002-sp06a.58", 0x400000, 0x1BCFE48E),
    ("002-sp07a.59", 0x400000, 0xA5049BD7),
    ("002-sp08a.60", 0x400000, 0xC2E57813),
    ("002-tx01a.1", 0x400000, 0x233749B5),
    ("002-tx02a.2", 0x400000, 0xD5074BE2),
    ("002-tx03a.3", 0x400000, 0x68C313F7),
    ("002-tx04a.4", 0x400000, 0xF7DAC24F),
    ("002-vt01a.17", 0x400000, 0x403FD7FD),
    ("002-vt02a.18", 0x400000, 0xE1885905),
    ("002-vt03a.19", 0x400000, 0x2074A6A6),
    ("002-vt04a.20", 0x400000, 0xAEFC4D94),
    ("002-vt05a.21", 0x400000, 0xD32EE9CB),
    ("002-vt06a.22", 0x400000, 0x13BF3636),
    ("002-sd01a.77", 0x400000, 0x6215036B),
    ("002-sd02a.78", 0x400000, 0x32B28310),
    ("002-sd03a.79", 0x400000, 0x53591413),
]

SYSTEM_ROMS = [   # (nom, taille, CRC-32, obligatoire) comme tools/install/build_from_rom.py de ReBuriki
    ("brom1.bin", 0x80000, 0xA30DD3DE, True),          # BIOS Japon (le code du jeu a ete lu avec celui-ci)
    ("tmp87ph40an.bin", 0x8000, 0xB70DF21F, True),     # microcontroleur de la carte d'E/S
    ("bios_us.bin", 0x80000, 0xAB5948D6, False),
    ("bios_export.bin", 0x80000, 0xBBF07EC6, False),
    ("bios_korea.bin", 0x80000, 0xAC953E2E, False),
]


def index(path):
    try:
        z = zipfile.ZipFile(path)
    except (OSError, zipfile.BadZipFile) as e:
        sys.exit(f"erreur: {path} illisible ({e})")
    return z, {(i.file_size, i.CRC): i for i in z.infolist() if not i.is_dir()}


def extract(z, info, out, crc):
    os.makedirs(os.path.dirname(out), exist_ok=True)
    c = 0
    with z.open(info) as s, open(out, "wb") as d:
        while True:
            b = s.read(1 << 20)
            if not b:
                break
            c = zlib.crc32(b, c)
            d.write(b)
    if c != crc:
        sys.exit(f"erreur: {os.path.basename(out)} est corrompu dans le zip")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--fork", required=True)
    ap.add_argument("--game", required=True)
    ap.add_argument("--bios", required=True)
    a = ap.parse_args()
    gz, gi = index(a.game)
    bz, bi = index(a.bios)
    missing = [n for n, s, c in GAME_ROMS if (s, c) not in gi]
    if missing:
        sys.exit(f"erreur: {len(missing)} fichier(s) manquants ou differents dans {os.path.basename(a.game)}: "
                 + ", ".join(missing[:6]) + (" ..." if len(missing) > 6 else ""))
    miss = [n for n, s, c, req in SYSTEM_ROMS if req and (s, c) not in bi]
    if miss:
        sys.exit(f"erreur: {os.path.basename(a.bios)} ne contient pas: {', '.join(miss)}")
    for n, s, c in GAME_ROMS:
        extract(gz, gi[(s, c)], os.path.join(a.fork, "roms", "sams64", n), c)
    for n, s, c, req in SYSTEM_ROMS:
        if (s, c) in bi:
            extract(bz, bi[(s, c)], os.path.join(a.fork, "roms", "hng64", n), c)
        else:
            print(f"note: {n} absent (region de repli: Japon)")
    print(f"OK: {len(GAME_ROMS)} fichiers du jeu et le BIOS dans {os.path.join(a.fork, 'roms')}")


if __name__ == "__main__":
    main()
