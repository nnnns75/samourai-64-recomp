#!/usr/bin/env python3
"""
Traduit le code de Samurai Shodown 64 en C avec N64Recomp, dans une copie (fork) de ReBuriki. Linux ou Windows.

    python3.11 translate_sams64.py --fork ~/SamuRecomp --game sams64.zip --n64recomp ~/N64Recomp

Ce que ca fait (memes etapes que tools/install/build_from_rom.py de ReBuriki, sans compiler le jeu):
  1. extract_sams64.py -> <fork>/work/   (code, amorce, zone basse + listes de fonctions)
  2. installe sections_sams64.py comme tools/sections.py (l'original est gardé en tools/sections_buriki.py),
     les listes dans tools/data/, et recomp/sams64.toml
  3. make_symbols.py -> sams64.syms.toml ; find_kernel_funcs.py (verifie que chaque fonction "noyau" est dans `ignored`)
  4. N64Recomp sams64.toml -> recomp/generated/ ; fix_generated.py
Rien de ce qui est ecrit dans <fork>/work ou <fork>/recomp/generated ne doit etre publie (derive de ta ROM).
"""
import argparse
import os
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
KIT = os.path.dirname(HERE)


def find(name):
    """Fichier du kit, que les fichiers soient ranges (tools/, recomp/) ou tous dans le meme dossier."""
    for d in (HERE, os.path.join(KIT, 'tools'), os.path.join(KIT, 'recomp'), KIT, os.getcwd()):
        p = os.path.join(d, name)
        if os.path.isfile(p):
            return p
    sys.exit(f"erreur: {name} introuvable (cherche a cote de ce script et dans {KIT}). Telecharge-le dans le meme dossier.")


def run(cmd, cwd, env, what):
    print('> ' + ' '.join(cmd), flush=True)
    p = subprocess.run(cmd, cwd=cwd, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, errors='replace')
    out = p.stdout or ''
    print(out.rstrip()[-3000:])
    if p.returncode != 0:
        sys.exit(f'erreur: {what} a echoue (code {p.returncode}).')
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--fork', required=True, help="dossier ReBuriki decompresse (ou ton fork)")
    ap.add_argument('--game', required=True, help='sams64.zip')
    ap.add_argument('--n64recomp', required=True, help="dossier N64Recomp (avec build/N64Recomp)")
    a = ap.parse_args()
    a.game = os.path.abspath(os.path.expanduser(a.game))               # les sous-programmes tournent dans d'autres dossiers
    a.n64recomp = os.path.abspath(os.path.expanduser(a.n64recomp))
    fork, py = os.path.abspath(os.path.expanduser(a.fork)), sys.executable
    tools, rdir, work = (os.path.join(fork, 'tools'), os.path.join(fork, 'recomp'), os.path.join(fork, 'work'))
    exe = os.path.join(a.n64recomp, 'build', 'N64Recomp.exe' if os.name == 'nt' else 'N64Recomp')
    for p in (tools, rdir, exe):
        if not os.path.exists(p):
            sys.exit(f'erreur: {p} introuvable')
    os.makedirs(work, exist_ok=True)
    env = dict(os.environ, BURIKI_WORK=work, PYTHONPATH=tools)

    ex = find('extract_sams64.py')
    find('analyze_hng64_game.py')
    run([py, ex, '--game', a.game, '--out', work], os.path.dirname(ex), env, "l'extraction")

    sec, bk = os.path.join(tools, 'sections.py'), os.path.join(tools, 'sections_buriki.py')
    if not os.path.exists(bk):
        shutil.copyfile(sec, bk)
    shutil.copyfile(find('sections_sams64.py'), sec)
    for part in ('text', 'stub', 'low'):
        shutil.copyfile(os.path.join(work, f'functions_{part}.txt'), os.path.join(tools, 'data', f'functions_{part}_sams64.txt'))
    toml = open(find('sams64.toml'), encoding='utf-8').read().replace('\\"kernel.h\\"', '\\"kernel_sams64.h\\"')
    open(os.path.join(rdir, 'sams64.toml'), 'w', encoding='utf-8', newline='\n').write(toml)

    run([py, os.path.join(tools, 'make_symbols.py'), 'sams64.syms.toml'], rdir, env, 'make_symbols')
    run([py, os.path.join(tools, 'find_kernel_funcs.py'), 'sams64.syms.toml', 'kernel_funcs.txt'], rdir, env,
        'find_kernel_funcs (une fonction noyau manque dans `ignored` de sams64.toml)')
    gen = os.path.join(rdir, 'generated')
    shutil.rmtree(gen, ignore_errors=True)
    out = run([exe, 'sams64.toml'], rdir, env, 'N64Recomp')
    if 'Error' in out:
        sys.exit('erreur: N64Recomp a signale une erreur (voir ci-dessus).')
    run([py, os.path.join(tools, 'fix_generated.py'), 'generated'], rdir, env, 'fix_generated')
    run([py, find('fix_switches_sams64.py'), '--fork', fork], rdir, env, 'fix_switches (switch non reconnus)')
    n = sum(1 for f in os.listdir(gen) if f.startswith('funcs_'))
    print(f'\nOK: {n} fichiers C dans {gen}')


if __name__ == '__main__':
    main()
