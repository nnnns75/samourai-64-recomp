#!/usr/bin/env python3
"""Diagnostic automatique: pourquoi les palettes ne sont jamais chargees ?

1. (option) lance le jeu sous Wine avec BURIKI_COVERAGE -> liste des fonctions executees
2. trouve les fonctions qui utilisent le pointeur de palette (gp+0xED8 / 0x8006D968)
3. pour celles jamais executees, remonte la chaine des appelants jusqu'aux
   "portes": appel direct d'une fonction executee vers une fonction jamais executee
4. affiche le code (instructions + branches) avant chaque appel de porte

Usage:
  python3 autodiag_sams64.py --fork ~/SamuRecomp            # lance + analyse
  python3 autodiag_sams64.py --fork ~/SamuRecomp --no-run   # reutilise cov_auto.txt
Option: --frames 3000  --pal-patterns 0XED8,0X2698  --depth 6  --window 40
Necessite diagcov_sams64.py deja applique (BURIKI_COVERAGE)."""
import argparse, glob, os, re, subprocess, sys
from collections import defaultdict, deque

ap = argparse.ArgumentParser()
ap.add_argument("--fork", required=True)
ap.add_argument("--frames", type=int, default=3000)
ap.add_argument("--no-run", action="store_true")
ap.add_argument("--pal-patterns", default="0XED8,0X2698")
ap.add_argument("--depth", type=int, default=6)
ap.add_argument("--window", type=int, default=40)
ap.add_argument("--max-gates", type=int, default=6)
a = ap.parse_args()

fork = os.path.expanduser(a.fork)
gen = os.path.join(fork, "recomp", "generated")
cov_path = os.path.join(fork, "cov_auto.txt")

if not a.no_run:
    env = dict(os.environ)
    env.setdefault("WINEPREFIX", os.path.expanduser("~/.wine-ss64"))
    env["WINEDEBUG"] = "-all"
    env["BURIKI_COVERAGE"] = "cov_auto.txt"
    if os.path.exists(cov_path):
        os.remove(cov_path)
    cmd = ["xvfb-run", "-a", "wine", "build/samurecomp.exe", "--headless", "--no-sound",
           "--frames", str(a.frames), "--roms", "roms"]
    print("lancement du jeu (%d images)..." % a.frames, flush=True)
    subprocess.run(cmd, cwd=fork, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

if not os.path.exists(cov_path):
    sys.exit("cov_auto.txt absent: le jeu n'a pas ecrit de couverture (diagcov applique ?)")
executed = set(re.findall(r"func_[0-9A-F]+", open(cov_path, errors="replace").read()))
print("fonctions executees:", len(executed))

files = {}
callers = defaultdict(set)      # callee -> {caller}
callsite = {}                   # (caller, callee) -> (file, index)
pal_users = set()
pats = [p.strip() for p in a.pal_patterns.split(",") if p.strip()]
rf = re.compile(r"^RECOMP_FUNC void (func_[0-9A-F]+)\(")
rc = re.compile(r"^\s*(func_[0-9A-F]{8})\(rdram, ctx\);")
allfuncs = set()
for f in sorted(glob.glob(os.path.join(gen, "funcs_*.c"))):
    L = open(f, errors="replace").read().split("\n")
    files[f] = L
    cur = None
    for i, l in enumerate(L):
        m = rf.match(l)
        if m:
            cur = m.group(1); allfuncs.add(cur); continue
        if cur is None:
            continue
        m = rc.match(l)
        if m:
            callers[m.group(1)].add(cur)
            callsite.setdefault((cur, m.group(1)), (f, i))
        # pointeur de palette = mot a 0x8006D968: soit gp+0xED8 (base r28), soit lui 0x8007 / -0x2698
        # (base AUTRE que r28: avec r28, -0x2698 est gp-0x2698 = 0x8006A3F8, une autre variable !)
        if re.search(r"MEM_[A-Z]+\(ctx->r28, 0XED8\)", l):
            pal_users.add(cur)
        elif re.search(r"MEM_[A-Z]+\(ctx->r(?!28\b)\d+, -0X2698\)", l):
            pal_users.add(cur)

print("fonctions utilisant le pointeur de palette:", len(pal_users))
run = sorted(x for x in pal_users if x in executed)
never = sorted(x for x in pal_users if x not in executed)
print("  executees :", ", ".join(run) or "-")
print("  JAMAIS executees:", ", ".join(never) or "-")

# remontee des appelants
gates = defaultdict(set)   # (caller_executed, callee_not_executed) -> cibles
nocaller = []
for t in never:
    seen = {t}; q = deque([(t, 0)]); found = False
    while q:
        n, d = q.popleft()
        cs = callers.get(n, set())
        if not cs and n == t:
            nocaller.append(t)
        for c in cs:
            if c in executed:
                gates[(c, n)].add(t); found = True
            elif c not in seen and d + 1 < a.depth:
                seen.add(c); q.append((c, d + 1))
    if not found and t not in nocaller:
        nocaller.append(t)

print()
if nocaller:
    print("Sans chemin direct depuis du code execute (appel par pointeur/table ou code mort):")
    print("  ", ", ".join(sorted(set(nocaller))))
print()
ranked = sorted(gates.items(), key=lambda kv: -len(kv[1]))[:a.max_gates]
if not ranked:
    print("Aucune porte directe trouvee.")
for (c, n), tg in ranked:
    f, i = callsite[(c, n)]
    print("=" * 70)
    print("PORTE: %s (executee) appelle %s (jamais executee), ligne %d de %s" % (c, n, i + 1, os.path.basename(f)))
    print("  mene a:", ", ".join(sorted(tg)))
    L = files[f]
    start = max(0, i - a.window * 3)
    out = []
    for j in range(start, i + 1):
        l = L[j]
        if re.match(r"^\s*// 0x[0-9A-F]+: ", l) and not l.startswith("        //"):
            out.append(l.strip())
        elif re.match(r"^L_[0-9A-F]+:", l):
            out.append(l.strip())
    print("  code juste avant l'appel (derniers %d):" % a.window)
    for l in out[-a.window:]:
        print("    ", l)
print()
print("Colle toute cette sortie.")
