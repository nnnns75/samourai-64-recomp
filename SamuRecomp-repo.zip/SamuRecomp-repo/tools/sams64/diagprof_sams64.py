#!/usr/bin/env python3
"""Profil: BURIKI_PROF_FROM=N -> a l'arret, affiche les 30 fonctions les plus appelees a partir de l'image N.
Prerequis: diagwatch_sams64.py ET diagcov_sams64.py deja appliques. Puis recompiler (hw.cpp seul).
    python3 diagprof_sams64.py --fork ~/SamuRecomp"""
import argparse, os, sys


def rep(t, old, new, what):
    if t.count(old) != 1:
        sys.exit(f"erreur: {what}: motif trouve {t.count(old)} fois (attendu 1)")
    return t.replace(old, new)


ap = argparse.ArgumentParser()
ap.add_argument("--fork", required=True)
a = ap.parse_args()
p = os.path.join(os.path.abspath(os.path.expanduser(a.fork)), "recomp", "runtime", "hw.cpp")
c = open(p, encoding="utf-8").read()
if "DIAGPROF" in c:
    print("deja applique"); sys.exit(0)
if "DIAGCOV" not in c:
    sys.exit("erreur: appliquer d'abord diagwatch_sams64.py puis diagcov_sams64.py")

c = rep(c, "#include <unordered_set>   // DIAGCOV\n",
        "#include <unordered_set>   // DIAGCOV\n#include <unordered_map>   // DIAGPROF\n#include <vector>\n#include <algorithm>\n", "include")
c = rep(c, "static std::set<std::string> g_cov;\n",
        "static std::set<std::string> g_cov;\nstatic std::unordered_map<const char*, uint64_t> g_prof;   // DIAGPROF\nstatic int g_prof_from = -1;\n", "etat")
c = rep(c, "void hw_watch_func(const char* name) {\n",
        "void hw_watch_func(const char* name) {\n    if (g_prof_from >= 0 && (int)g_frame >= g_prof_from) g_prof[name]++;\n", "entree")
c = rep(c, "    if (!g_watch_on) return;\n    if (!g_cov_path.empty()) {",
        '    if (!g_watch_on) return;\n    if (g_prof_from >= 0) {\n'
        '        std::vector<std::pair<uint64_t, const char*>> v;\n'
        '        for (auto& kv : g_prof) v.push_back({kv.second, kv.first});\n'
        '        std::sort(v.begin(), v.end(), [](auto& x, auto& y) { return x.first > y.first; });\n'
        '        for (size_t i = 0; i < v.size() && i < 30; i++) fprintf(stderr, "[prof] %10llu  %s\\n", (unsigned long long)v[i].first, v[i].second);\n'
        '    }\n    if (!g_cov_path.empty()) {', "rapport")
c = rep(c, '    if (const char* o = getenv("BURIKI_COVERAGE")) {',
        '    if (const char* pf = getenv("BURIKI_PROF_FROM")) { g_prof_from = atoi(pf); g_watch_on = 1; }\n    if (const char* o = getenv("BURIKI_COVERAGE")) {', "init")
open(p, "w", encoding="utf-8", newline="\n").write(c)
print("OK: profil ajoute (hw.cpp)")
