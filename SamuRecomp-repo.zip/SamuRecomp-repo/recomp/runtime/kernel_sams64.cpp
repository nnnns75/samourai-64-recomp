// Samurai Shodown 64: hand-written versions of the functions that use CPU control instructions, plus the
// interrupt path of the game's exception handler. Each one mirrors the original MIPS code, quoted in the
// comments (read from the ROM's own listing; see BOOT_PLAN.md). Style and helpers follow ReBuriki's kernel.cpp.
#include <cstdio>
#include "kernel_sams64.h"
#include "hw.h"

extern "C" {

// 800C9F90: write one TLB entry. a0 points to a parameter block of 32-bit words:
//   [0x00] flag bits added to both EntryLo values (C/D/V/G)   [0x04] index   [0x08] page mask
//   [0x0C] virtual address (EntryHi, low 13 bits cleared)     [0x10] physical address, even page
//   [0x14] physical address, odd page
//   Index = [4] ; PageMask = [8] ; EntryHi = [0xC] & 0xFFFFE000
//   EntryLo0 = (([0x10] >> 6) & 0x07FFFFC0) + [0] ; EntryLo1 = (([0x14] >> 6) & 0x07FFFFC0) + [0] ; tlbwi
// It saves and restores t0 and t1; it leaves t2 = [0x28] and t3 = [0x2C] (loaded just before the return).
void func_800C9F90(uint8_t* rdram, recomp_context* ctx) {
    (void)rdram;
    const gpr a0 = ctx->r4;
    const uint32_t flags    = (uint32_t)MEM_W(0x00, a0);
    const uint32_t index    = (uint32_t)MEM_W(0x04, a0);
    const uint32_t pagemask = (uint32_t)MEM_W(0x08, a0);
    const uint32_t entryhi  = (uint32_t)MEM_W(0x0C, a0) & 0xFFFFE000u;
    const uint32_t lo0 = (((uint32_t)MEM_W(0x10, a0) >> 6) & 0x07FFFFC0u) + flags;
    const uint32_t lo1 = (((uint32_t)MEM_W(0x14, a0) >> 6) & 0x07FFFFC0u) + flags;
    // hw_tlb_write takes physical page addresses: EntryLo = (physical >> 6) | flags, flags below 0x40.
    hw_tlb_write(index, pagemask, entryhi, (lo0 & ~0x3Fu) << 6, (lo1 & ~0x3Fu) << 6);
    ctx->r11 = (gpr)(int32_t)MEM_W(0x2C, a0);    // t3
    ctx->r10 = (gpr)(int32_t)MEM_W(0x28, a0);    // t2
}

// 800CA018: set the cache mode: Config = (Config & ~0x3F) | 0x23. There are no caches in the recomp.
// (The original leaves a0 = the new Config value; the game has no reason to read it.)
void func_800CA018(uint8_t* rdram, recomp_context* ctx) { (void)rdram; (void)ctx; }

// 800CA03C: invalidate the instruction cache (cache op 0, 0x80000000-0x80004000, step 0x20), set Config = ... | 0x22,
// write back + invalidate the data cache (cache op 1, 0x80000000-0x80002000, step 0x10). Nothing to do here;
// the original leaves its loop registers behind: a0 = a1 = 0x80002000, a2 = 0x10.
void func_800CA03C(uint8_t* rdram, recomp_context* ctx) {
    (void)rdram;
    ctx->r4 = ctx->r5 = (gpr)(int32_t)0x80002000u;
    ctx->r6 = 0x10;
}

// 800CA124: Config = ... | 0x22 (a 'cache' loop follows), then invalidate the data cache 0x80380000-0x80382000. It saves and restores
// t0-t2 and touches nothing else: no visible effect without caches.
void func_800CA124(uint8_t* rdram, recomp_context* ctx) { (void)rdram; (void)ctx; }

// 800CA09C: save t0-t2, run 'cache' (op 0x01 = write back + invalidate data) over 0x80000000-0x80002000 in 16-byte
// steps, restore t0-t2. 800CA0E0: the same with 'cache' op 0x00 over 0x80300000-0x80304000 in 32-byte steps. Both
// restore everything they use except the sp frame, which they also restore: no visible effect without caches.
void func_800CA09C(uint8_t* rdram, recomp_context* ctx) { (void)rdram; (void)ctx; }
void func_800CA0E0(uint8_t* rdram, recomp_context* ctx) { (void)rdram; (void)ctx; }

// The interrupt path of the exception handler at 0x80000800 (ROM 0x500, read from the listing):
//   level = lw 0xBF701104 ; sw level, 0x80000478 ; if (level >= 24) level = 13
//   counter = lbu 0x80000460 + level ; sb counter + 1, 0x80000460 + level
//   sw (1 << level), 0xBF70111C ; sw ((level >> 3) << 6), 0xBF70111C        (acknowledge)
//   (the original now re-enables interrupts: Status = (Status | 0x1F) ^ 0x1F | 1)
//   handler = lw 0x80000400 + 4 * level ; jalr handler
//   sb counter, 0x80000460 + level                                          (puts the byte back as it was)
// The original also saves and restores the registers, HI/LO, Status, EPC and ends with eret: hw_events() already
// saves the whole CPU state around this call and restores it afterwards, so none of that is repeated.
// Interrupts are not nested (hw_events does not deliver one while another is running), so Status is left alone.
// Registers at the call, as the original leaves them: v0 = handler, v1 = (level >> 3) << 6,
// a0 = 0xBF700000, a1 = counter + 1.
void sams_irq_dispatch(uint8_t* rdram, recomp_context* ctx) {
    const gpr SYS = (gpr)(int32_t)0xBF700000u;
    const gpr LOW = (gpr)(int32_t)0x80000000u;
    ctx->r29 -= 0x90;                                        // addiu sp, sp, -144
    uint32_t level = (uint32_t)MEM_W(0x1104, SYS);
    MEM_W(0x478, LOW) = level;
    if ((int32_t)level >= 24) level = 13;
    const uint8_t counter = (uint8_t)MEM_BU(0x460 + (int)level, LOW);
    MEM_B(0x460 + (int)level, LOW) = (uint8_t)(counter + 1);
    MEM_W(0x111C, SYS) = 1u << level;
    MEM_W(0x111C, SYS) = (level >> 3) << 6;
    const uint32_t handler = (uint32_t)MEM_W(0x400 + (int)(level * 4), LOW);
    if (handler == 0)
        hw_fatal("interrupt level %u has no handler in the table at 80000400", level);
    ctx->r2 = (gpr)(int32_t)handler;
    ctx->r3 = (gpr)((level >> 3) << 6);
    ctx->r4 = SYS;
    ctx->r5 = (gpr)(counter + 1);
    get_function((int32_t)handler)(rdram, ctx);
    MEM_B(0x460 + (int)level, LOW) = counter;
}

} // extern "C"
