// Samurai Shodown 64: hand-written replacements for what N64Recomp can't translate
// (see recomp/sams64.toml [patches] ignored, and BOOT_PLAN.md). Mirrors runtime/kernel.h of ReBuriki (MIT).
#ifndef SAMS64_KERNEL_H
#define SAMS64_KERNEL_H

#include "recomp.h"

#ifdef __cplusplus
extern "C" {
#endif

// Game code (addresses as loaded in RAM)
void func_800C9F90(uint8_t* rdram, recomp_context* ctx); // write one TLB entry (a0 = parameter block)
void func_800CA018(uint8_t* rdram, recomp_context* ctx); // set the cache mode (Config)
void func_800CA03C(uint8_t* rdram, recomp_context* ctx); // flush both caches + set the cache mode
void func_800CA124(uint8_t* rdram, recomp_context* ctx); // set the cache mode + flush the data cache
void func_800CA09C(uint8_t* rdram, recomp_context* ctx); // invalidate the data cache (cache ops)
void func_800CA0E0(uint8_t* rdram, recomp_context* ctx); // invalidate a cache range (cache ops)

// The exception handler at 0x80000800 (ROM 0x500), interrupt path only. Call it instead of
// ReBuriki's func_800C2B20 in hw_events(): see BOOT_PLAN.md section 3.
void sams_irq_dispatch(uint8_t* rdram, recomp_context* ctx);

#ifdef __cplusplus
}
#endif

#endif
