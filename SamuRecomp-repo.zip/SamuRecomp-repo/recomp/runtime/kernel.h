// SS64: le noyau ecrit a la main est dans kernel_sams64.h (kernel.cpp de Buriki retire).
#include "kernel_sams64.h"
