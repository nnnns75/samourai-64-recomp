# Samurai Shodown 64 : ce que le crt0 de ta ROM nous apprend

Tout vient du listing de l'amorce (`listing_200.txt`, ROM 0x200-0x6B0) et des fichiers `kernel_candidates.txt` /
`functions_seed.txt` que tu as produits. **Rien ici n'a ete execute**: ce sont des lectures de code, verifiees
par le calcul quand c'est indique.

## 1. Ce qui est verifie

- Le jeu est reconnu: titre `SAMURAI SPIRITS 64`, marqueur `HYPER NEOGEO64`.
- **Deux methodes independantes donnent la meme adresse de chargement du code**:
  - l'analyse des appels `jal` : base `0x800BAEA0` pour une fenetre commencant a ROM 0x200 (97 % des appels tombent sur un debut de fonction);
  - la copie n°3 du crt0 : ROM 0x5360 -> 0x800C0000, soit `0x800C0000 - (0x5360 - 0x200) = 0x800BAEA0`. Identique a l'octet.
- Les trois copies de donnees sont contigues dans la ROM (la copie 2 finit en ROM 0x5360 ou commence la 3, la 3 finit en
  0xA3E60 ou commence la 4). La fin du code `0x8015EB00` est exactement la fin de la copie 3.

## 2. Sequence de demarrage decodee

L'en-tete ne fait copier au BIOS que **4 Ko** (ROM 0x200 -> 0x80001000), puis saute en 0x80001000. Le reste est charge
par le crt0 lui-meme (different de Buriki One, ou le BIOS copiait 13 Mo):

| Etape | Ce que fait le crt0 | Valeurs |
|---|---|---|
| 1 | pile et gp | `sp = 0x80004000`, `gp = 0x8006CA90` |
| 2 | remise a zero de registres systeme, test de RAM (fonction 0x80001240, motifs 0x55555555/0xAAAAAAAA) | sur 0x80000000-0x80001000 puis 0x80001800-0x80400000 |
| 3 | copie 1 : gestionnaire d'exceptions | ROM 0x500, 0x500 octets -> `0x80000800` |
| 4 | copie 2 : donnees | ROM 0xA00, 0x4960 octets -> `0x8006AA00` |
| 5 | copie 3 : **code du jeu** | ROM 0x5360, 0x9EB00 octets -> `0x800C0000` (fin `0x8015EB00`) |
| 6 | copie 4 : donnees apres le code | ROM 0xA3E60, 0x148700 octets -> `0x80180000` |
| 7 | vecteurs d'exception (5 mots copies 3 fois) | 0x80000000, 0x80000080, 0x80000180 : `lui k0,0x8000 ; ori k0,0x800 ; jr k0` |
| 8 | remise a zero de la zone BSS | `0x80004000` .. `0x8006A9F4` |
| 9 | **`jal 0x800CEF50` = `main`** | |

Les sources des copies sont lues a l'adresse `0xA4000000 + offset` : fenetre cartouche physique `0x04000000`, comme dans ReBuriki.
La zone `0x80004000+` est mise a zero : la ou ReBuriki trouve les services BIOS. Le jeu ne les appelle donc **probablement**
pas par la copie en RAM (a verifier au premier demarrage: le runtime de ReBuriki signale tout service inconnu).

## 3. Interruptions : le gestionnaire est dans la ROM, avec des `eret`

Le vecteur `0x80000180` saute en `0x80000800`. Ce gestionnaire (lu dans le listing) fait, en resume:

```
sauvegarde des registres, Status, Cause, EPC, HI, LO
exccode = (Cause >> 2) & 0x1F
si exccode != 0 -> autre exception (suite non lue, a partir de 0x80001490)
si Cause.IP2 (bit 10) == 0 -> restaure et eret
niveau = lire(0x1F701104)            # meme registre que dans ReBuriki
ecrire(0x80000478, niveau)
si niveau >= 24 : niveau = 13
compteur_imbrication[0x80000460 + niveau] += 1
ecrire(0x1F70111C, 1 << niveau) ; ecrire(0x1F70111C, (niveau >> 3) << 6)     # acquittement
reactive les interruptions (Status = Status sans EXL/KSU, IE=1)
appelle  *(uint32*)(0x80000400 + 4*niveau)                                    # table de handlers
restaure, decremente le compteur, eret
```

C'est la meme logique que le dispatcheur `func_800C2B20` de Buriki One (niveau lu en 0x1F701104, table en 0x80000400),
mais **ici il est dans la zone amorce, avec `eret`/`mtc0`/`mfc0`**, donc N64Recomp ne peut pas le traduire. Il faut
l'ecrire a la main dans le runtime et le brancher a la place de `func_800C2B20(rdram, ctx)` dans `hw_events` (hw.cpp ~l.800).
Le plus simple: reproduire les lignes ci-dessus en C++ puis appeler la fonction pointee par la table.

## 4. Fonctions "noyau"

| Fonction (adresse reelle) | Instructions | Verdict |
|---|---|---|
| `func_800C9F90` | mtc0 EntryHi/EntryLo0/EntryLo1/Index/PageMask, `tlbwi` | ecriture TLB: a ecrire (cf. `func_800C5C90` de ReBuriki) |
| `func_800CA018`, `func_800CA03C`, `func_800CA124` | mfc0/mtc0 Config | reglage du cache: probablement des no-ops comme ceux de ReBuriki |
| `func_800BB184` | eret, Cause, EPC | **n'est pas une fonction du code du jeu**: c'est le vecteur + le gestionnaire (ROM 0x4E4..), traite au point 3 |
| `func_800BB6A0` | ~30 variantes COP0 | **faux positif**: ce sont des donnees (ROM 0xA00, copie 2) |
| `func_8015EB00` | ~15 variantes COP0 | **faux positif**: c'est la frontiere exacte code/donnees (debut de la copie 4) |

Pas de fonction lisant `Count` : il n'y a pas d'equivalent du generateur aleatoire de ReBuriki a reecrire (a confirmer).

## 5. Changements concrets dans le fork de ReBuriki

1. `tools/sections.py` <- `tools/sections_sams64.py`; `tools/data/functions_*` <- sorties de `extract_sams64.py` (puis Ghidra).
2. `recomp/buriki.toml` -> `recomp/sams64.toml` (liste `ignored` ci-dessus) et `kernel.cpp`/`kernel.h`: remplacer les 7 fonctions de Buriki.
3. `recomp/runtime/main.cpp` ~l.291: `func_80008000` -> `func_80001000` (le crt0 de SS64).
4. `hw.cpp` `hw_events`: remplacer l'appel `func_800C2B20` par le gestionnaire du point 3.
5. `hw.cpp` `hw_boot`: la copie de l'en-tete (+0x50/0x54/0x58) et l'entree (+0x5C) sont lues dans l'en-tete de la ROM: probablement
   deja correctes. Reste le reste de `PORTING_MAP.md` (options operateur, controles, menus), non commence.

## 6. Ce qui reste incertain

- Les listes de fonctions sont des **graines** : a affiner dans Ghidra (une mauvaise coupure se voit plus tard: crash ou erreur de table de sauts).
- La suite du gestionnaire (exceptions autres que les interruptions) n'est pas lue.
- La copie 4 (`0x80180000`, 1,3 Mo) a ete classee comme donnees d'apres la densite d'instructions (aucun prologue de fonction); a confirmer.
- Carte d'E/S, effets sonores, rendu 3D propres a SS64: **non verifies**, voir `PORTING_MAP.md`.

## 6. Mise a jour (etat reel apres traduction de la ROM)

- Section `.low` (0x80000800, gestionnaire d'exception + 9 fonctions 0x80000A98..0x80000CE8) et section `.stub` (0x80001000, 1er bloc de 4 Ko).
- Les fonctions `cache` (func_800CA09C/0E0) et COP0 sont ecrites a la main (`runtime/kernel_sams64.*`).
- Les tables de saut sont lues a la meme distance de la fonction que dans l'image: `.text` est donc construite depuis une image memoire continue
  (`sams64_image_8006AA00.bin`).
- Disposition des ROM: `tools/unpack_roms_sams64.py` ecrit `roms/sams64/` (33 fichiers, CRC MAME) et `roms/hng64/`.
- Runtime: `tools/apply_sams64_patch.py` (ROM programme 2 paires, scroll/sprites 32 Mo, 6 ROM de vertex, 3 ROM son, entree func_80001000,
  interruptions par `sams_irq_dispatch`).
- A verifier au premier demarrage: bit FR de Status (deux fonctions ecrivent FR=0), entree = en-tete 0x5C, chemin d'exception hors interruption (`j 0x800C0840`),
  adresses propres a Buriki dans netplay/savestate (0x800F3A51, 0x801446E0...) : inutilisables tant qu'elles ne sont pas refaites.

## 7. Palettes: cause trouvee (registre vblank)

Symptome: 3D grise/sombre, palette quasi vide (3 entrees ecrites par le jeu), jeu en apparence "bloque".
Cause: `func_800C52C4` (chargeur de palettes, appele a chaque image) copie ses 16 banques de 0x400 octets
du tampon RAM vers la RAM palette (0x20200000) **uniquement si `lhu(tcram + 0x4A) == 0xFFFF`**.
tcram+0x48 est le registre de statut vblank: MAME le declare `PORT_BIT(0xffffffff, IP_ACTIVE_HIGH, IPT_CUSTOM)`
(vblank = 0xFFFFFFFF), alors que le runtime ReBuriki renvoie 1 (Buriki se contente d'un test non nul).
Correctif: hw.cpp `case 0x20208048: v = g_in_vblank ? 0xFFFFFFFFu : 0;` (tools/fix_vblank_sams64.py,
integre a apply_sams64_patch.py). Resultat: ecran de selection colore, scenes 3D en couleurs.

Methode qui a marche (reutilisable pour les autres jeux HNG64): profil des fonctions les plus appelees
(diagprof), couverture (diagcov), "portes" executee->jamais executee (autodiag_sams64.py), puis lecture du code
du chargeur et de ce qu'il lit dans le materiel. Piege rencontre: `-0x2698` avec base gp (r28) est
gp-0x2698 = 0x8006A3F8, pas le pointeur palette 0x8006D968 (lui 0x8007 / -0x2698).

A verifier ensuite: CREDIT reste a 0 apres coin1 (image 3000) dans les captures; scenes monochromes
(images 2600/2800) a comparer a MAME; son; menus/controles/ecran large.

## 8. Options de l'interface (heritees de ReBuriki)

Generiques (marchent telles quelles): mode d'affichage (fenetre / sans bordure / exclusif), taille, ecran, ratio
(arcade / etire / entier / large), filtres (net / lisse / lignes de balayage), cadence (arcade 59,43 Hz / vsync),
carte graphique, compteur FPS, volume / muet, controles clavier + manette (remappage), region (BIOS), captures.
A tester sur SS64: qualite "haute definition" (hd3d), "HUD aux bords" en ecran large.

Propres a Buriki One, neutralises par tools/options_sams64.py (grisees, aucune ecriture memoire):
- Unlock Silber (nvram+0x20F0, RAM 0x000F3990)
- Options d'arcade: Free play, difficulte, puissance d'attaque, duree, replay, continue, sang, affichage des
  commandes (nvram 0x2030/0x2050 <-> RAM 0x801446E0/F0). A cartographier pour SS64: changer chaque option du
  menu Test (F2) et comparer nvram.bin avant/apres.
- Jeu en ligne (netplay.cpp: WAIT_SP 0x803FFFC0 = pile de la boucle principale de Buriki; sauvegardes d'etat).
- hw_fight_in_progress (RAM 0x800F3A51) ne sert qu'au role des sticks en combat: a recartographier.
Renommage de l'interface: tools/rename_sams64.py.

## 9. Fix: bottom of the 3D picture cut (video3d.cpp)

Fight projection packets carry a 512x448 window shifted vertically (words 10-13: right 0x100, left -0x100, top 0xF4..0x104, bottom -0xCC..-0xBC). The Buriki "how to play" viewport logic took it for a viewport and clipped or wrapped the bottom of the 3D layer. A full-size window now uses the packet's own frustum values, with no viewport (as MAME does).
