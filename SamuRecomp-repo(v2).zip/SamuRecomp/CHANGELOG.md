# Changes

## Display fixes
- **Palettes**: the vblank status register (0x20208048) now reads 0xFFFFFFFF during vblank, as in MAME. The game tests it
  before copying its palettes; with the old value everything stayed black.
- **Bottom of the 3D picture**: fight scenes send a 512 x 448 projection window shifted vertically (an off-centre
  frustum). The code inherited from ReBuriki read it as a viewport and cut or wrapped the bottom of the picture. A
  full-size window now uses the packet's own values, with no viewport (`recomp/runtime/video3d.cpp`).

## Interface and tools
- Interface renamed to Samurai Shodown 64; online play and "Unlock Silber" (Buriki One features) are neutralised.
- `translate_sams64.py` accepts relative paths.
